import os
import sys
import math
import numpy as np
import torch
from dataclasses import dataclass
from typing import Tuple, Dict, Optional, Union

# 本地实现CT工具的功能，避免依赖ct.utils

# 颜色定义
class Colors:
    YELLOW = "\033[93m"
    GREEN = "\033[92m"
    RED = "\033[91m"
    RESET = "\033[0m"

# 常量配置
class ConstConfig:
    MAX_LEN_SINGLE_HELP = 80

# 表格打印器
class TablePrinter:
    def __init__(self, col_widths, indent=2):
        self.col_widths = col_widths
        self.indent_str = " " * indent
        self.rows = []
    
    def add_row(self, *args):
        data = list(args) + [""] * (len(self.col_widths) - len(args))
        self.rows.append({"type": "data", "content": data})
    
    def add_separator(self):
        self.rows.append({"type": "sep"})
    
    def print(self, printer_func):
        if not self.rows:
            return
        printer_func("=" * 80)
        for row in self.rows:
            if row["type"] == "data":
                cells = []
                for i, text in enumerate(row["content"]):
                    padded_text = str(text).ljust(self.col_widths[i])
                    cells.append(f" {padded_text} ")
                line = self.indent_str + "│" + "│".join(cells) + "│"
                printer_func(line)
            elif row["type"] == "sep":
                printer_func("=" * 80)
        printer_func("=" * 80)

# 通用工具函数
class common:
    Colors = Colors
    ConstConfig = ConstConfig
    
    @staticmethod
    def print_log(msg):
        print(msg)
    
    @staticmethod
    def ensure_dir(directory):
        if not os.path.exists(directory):
            try:
                os.makedirs(directory)
            except OSError as e:
                common.print_log(f"Error creating directory {directory}: {e}")

# 延迟导入可视化相关模块，避免matplotlib依赖问题
try:
    from ct.viz import plot_diff, plot_spatial_error
    VIZ_AVAILABLE = True
except ImportError:
    # 如果导入失败，禁用可视化功能
    from ct.viz import plot_diff, plot_spatial_error
    VIZ_AVAILABLE = True

# ==========================================
# 1. 生态算子精度标准配置
# ==========================================

# --- A. 数据类型阈值配置 ---
# 生态算子开源精度标准
ECO_DTYPE_CONFIGS = {
    "float16": {
        "threshold": 2**(-10),  # 1.0e-3 级别
        "desc": "Half Precision"
    },
    "bfloat16": {
        "threshold": 2**(-7),   # 7.8e-3 级别
        "desc": "Brain Float 16"
    },
    "float32": {
        "threshold": 2**(-13),  # 1.2e-4 级别
        "desc": "Single Precision"
    },
    "hifloat32": {
        "threshold": 2**(-11),  # 4.9e-4 级别
        "desc": "High Performance Float 32"
    },
    "float8_e4m3": {
        "threshold": 2**(-3),   # 1.25e-1 级别
        "desc": "Float8 E4M3 Format"
    },
    "float8_e5m2": {
        "threshold": 2**(-2),   # 2.5e-1 级别
        "desc": "Float8 E5M2 Format"
    }
}

# 兼容 numpy 和 torch 的 dtype 映射键值
DTYPE_MAP = {
    np.float32: "float32",
    np.float16: "float16",
    torch.float32: "float32",
    torch.float16: "float16",
    torch.bfloat16: "bfloat16",
    "fp32": "float32",
    "fp16": "float16",
    "bf16": "bfloat16",
    "hifp32": "hifloat32",
    "fp8_e4m3": "float8_e4m3",
    "fp8_e5m2": "float8_e5m2"
}

# ==========================================
# 2. 核心配置类
# ==========================================

@dataclass
class EcoBenchConfig:
    """生态算子精度验证配置"""
    # 数据类型信息（没有默认值，放在前面）
    dtype_key: str
    dtype_desc: str
    
    # 误差阈值（没有默认值，放在前面）
    threshold: float
    ten_times_threshold: float
    
    # 小值域定义（有默认值，放在后面）
    small_val_thd: float = 1e-7

def resolve_eco_config(dtype: Union[str, np.dtype, torch.dtype], args=None) -> EcoBenchConfig:
    """
    工厂函数：根据数据类型生成生态算子精度验证配置
    """
    # 1. 解析数据类型
    dtype_key = "float32"  # 默认 fallback
    if isinstance(dtype, str):
        dtype_key = DTYPE_MAP.get(dtype.lower(), dtype.lower())
    else:
        # 处理 numpy 或 torch 的 dtype 对象
        dtype_key = DTYPE_MAP.get(dtype, "float32")
    
    if dtype_key not in ECO_DTYPE_CONFIGS:
        common.print_log(f"[Warning] Unknown dtype '{dtype_key}', utilizing float32 fallback.")
        dtype_key = "float32"
    
    dtype_cfg = ECO_DTYPE_CONFIGS[dtype_key]
    
    # 2. 创建配置对象
    threshold = dtype_cfg["threshold"]
    config = EcoBenchConfig(
        dtype_key=dtype_key,
        dtype_desc=dtype_cfg["desc"],
        threshold=threshold,
        ten_times_threshold=10 * threshold,
        small_val_thd=1e-7  # 固定小值域阈值以避免除零
    )
    
    # 3. 处理参数覆盖
    if args is not None:
        if hasattr(args, 'threshold') and args.threshold is not None:
            config.threshold = args.threshold
            config.ten_times_threshold = 10 * config.threshold
            common.print_log(f"  [Override] threshold overridden to: {config.threshold}")
        
        if hasattr(args, 'small_val_thd') and args.small_val_thd is not None:
            config.small_val_thd = args.small_val_thd
            common.print_log(f"  [Override] small_val_thd overridden to: {config.small_val_thd}")
    
    return config

# ==========================================
# 3. 核心验证类
# ==========================================

@dataclass
class EcoMetricResult:
    """生态算子精度验证结果"""
    # 基本统计信息
    total_samples: int
    
    # 误差指标
    mere: float  # 平均相对误差
    mare: float  # 最大相对误差
    
    # 通过率统计
    pass_rate: float
    pass_status: bool
    
    # 详细信息
    abs_diff: Optional[np.ndarray] = None
    rel_diff: Optional[np.ndarray] = None

class EcoBenchmarkValidator:
    """生态算子精度验证器"""
    
    def __init__(self, config: EcoBenchConfig):
        self.config = config
    
    def calculate_metrics(self, test_data: np.ndarray, golden_data: np.ndarray) -> EcoMetricResult:
        """
        计算生态算子精度指标
        """
        # 数据预处理
        test_data = test_data.astype(np.float32)
        golden_data = golden_data.astype(np.float32)
        
        # 确保数据形状一致
        if test_data.shape != golden_data.shape:
            raise ValueError(f"Shape mismatch: {test_data.shape} vs {golden_data.shape}")
        
        total_samples = test_data.size
        
        # 计算绝对误差
        abs_diff = np.abs(test_data - golden_data)
        
        # 计算相对误差（避免除零）
        rel_diff = abs_diff / (np.abs(golden_data) + self.config.small_val_thd)
        
        # 计算指标
        mere = np.mean(rel_diff)
        mare = np.max(rel_diff)
        
        # 判断是否通过
        mere_pass = mere < self.config.threshold
        mare_pass = mare < self.config.ten_times_threshold
        pass_status = mere_pass and mare_pass
        
        # 计算通过率（这里所有样本要么都通过要么都不通过，因为是基于全局指标）
        pass_rate = 1.0 if pass_status else 0.0
        
        return EcoMetricResult(
            total_samples=total_samples,
            mere=mere,
            mare=mare,
            pass_rate=pass_rate,
            pass_status=pass_status,
            abs_diff=abs_diff,
            rel_diff=rel_diff
        )
    
    def compare(self, test_data: np.ndarray, golden_data: np.ndarray) -> EcoMetricResult:
        """
        执行生态算子精度比较
        """
        return self.calculate_metrics(test_data, golden_data)

# ==========================================
# 4. 报告生成
# ==========================================

def print_eco_report(config: EcoBenchConfig, result: EcoMetricResult, test_data=None, golden_data=None, show_viz=True, viz_dir=None, viz_name="eco_viz"):
    """
    打印生态算子精度验证报告
    """
    separator = "=" * ConstConfig.MAX_LEN_SINGLE_HELP
    divider = "-" * ConstConfig.MAX_LEN_SINGLE_HELP
    
    # 创建报告输出目录
    if viz_dir:
        common.ensure_dir(viz_dir)
    
    # 收集报告内容
    report_content = []
    
    # 添加标题
    report_content.append(separator)
    # 动态居中标题
    title = "生态算子精度验证报告"
    report_content.append(f" {title:^{ConstConfig.MAX_LEN_SINGLE_HELP - 12}} ")
    report_content.append(divider)
    
    # 打印到控制台
    common.print_log(separator)
    common.print_log(f" {title:^{ConstConfig.MAX_LEN_SINGLE_HELP - 12}} ")
    common.print_log(divider)
    
    # 1. 配置信息
    config_title = "[验证配置]:"
    report_content.append(config_title)
    common.print_log(f"{Colors.YELLOW}{config_title}{Colors.RESET}")
    
    data_type_line = f"  数据类型: {config.dtype_key} ({config.dtype_desc})"
    report_content.append(data_type_line)
    common.print_log(data_type_line)
    
    mere_thd_line = f"  MERE阈值: {config.threshold:.6e}"
    report_content.append(mere_thd_line)
    common.print_log(mere_thd_line)
    
    mare_thd_line = f"  MARE阈值: {config.ten_times_threshold:.6e} (10×MERE阈值)"
    report_content.append(mare_thd_line)
    common.print_log(mare_thd_line)
    
    small_val_thd_line = f"  小值域阈值: {config.small_val_thd:.6e}"
    report_content.append(small_val_thd_line)
    common.print_log(small_val_thd_line)
    
    report_content.append(divider)
    common.print_log(divider)
    
    # 2. 结果概览
    result_title = "[验证结果]:"
    report_content.append(result_title)
    common.print_log(f"{Colors.YELLOW}{result_title}{Colors.RESET}")
    
    status_color = Colors.GREEN if result.pass_status else Colors.RED
    status_text = "PASS" if result.pass_status else "FAIL"
    status_line = f"  验证结果: {status_text}"
    report_content.append(status_line)
    common.print_log(f"  验证结果: {status_color}{status_text}{Colors.RESET}")
    
    samples_line = f"  样本总数: {result.total_samples}"
    report_content.append(samples_line)
    common.print_log(samples_line)
    
    report_content.append(divider)
    common.print_log(divider)
    
    # 3. 误差指标
    metric_title = "[误差指标]:"
    report_content.append(metric_title)
    common.print_log(f"{Colors.YELLOW}{metric_title}{Colors.RESET}")
    
    # 平均相对误差
    mere_color = Colors.GREEN if result.mere < config.threshold else Colors.RED
    mere_line = f"  平均相对误差(MERE): {result.mere:.6e}"
    report_content.append(mere_line)
    common.print_log(f"  平均相对误差(MERE): {mere_color}{result.mere:.6e}{Colors.RESET}")
    
    mere_req_line = f"    阈值要求: MERE < {config.threshold:.6e}"
    report_content.append(mere_req_line)
    common.print_log(mere_req_line)
    
    # 最大相对误差
    mare_color = Colors.GREEN if result.mare < config.ten_times_threshold else Colors.RED
    mare_line = f"  最大相对误差(MARE): {result.mare:.6e}"
    report_content.append(mare_line)
    common.print_log(f"  最大相对误差(MARE): {mare_color}{result.mare:.6e}{Colors.RESET}")
    
    mare_req_line = f"    阈值要求: MARE < {config.ten_times_threshold:.6e}"
    report_content.append(mare_req_line)
    common.print_log(mare_req_line)
    
    report_content.append(divider)
    common.print_log(divider)
    
    # 4. 判定条件
    criteria_title = "[判定条件]:"
    report_content.append(criteria_title)
    common.print_log(f"{Colors.YELLOW}{criteria_title}{Colors.RESET}")
    
    mere_pass_line = f"  ✓ MERE < 阈值: {result.mere < config.threshold}"
    report_content.append(mere_pass_line)
    common.print_log(mere_pass_line)
    
    mare_pass_line = f"  ✓ MARE < 10×阈值: {result.mare < config.ten_times_threshold}"
    report_content.append(mare_pass_line)
    common.print_log(mare_pass_line)
    
    overall_pass_line = f"  ✓ 总体结果: {result.pass_status}"
    report_content.append(overall_pass_line)
    common.print_log(overall_pass_line)
    
    report_content.append(separator)
    common.print_log(separator)
    
    # 5. 可视化（可选）
    viz_title = "[可视化分析]:"

    if not VIZ_AVAILABLE:
        report_content.append(viz_title)
        common.print_log(f"{Colors.YELLOW}{viz_title}{Colors.RESET}")
        
        viz_warning_line = "  警告: 可视化功能不可用（缺少matplotlib依赖）"
        report_content.append(viz_warning_line)
        common.print_log(viz_warning_line)
        
        report_content.append(separator)
        common.print_log(separator)
    elif viz_dir and viz_name and test_data is not None and golden_data is not None:
        report_content.append(viz_title)
        common.print_log(f"{Colors.YELLOW}{viz_title}{Colors.RESET}")
        
        viz_processing_line = "  正在生成可视化结果..."
        report_content.append(viz_processing_line)
        common.print_log(viz_processing_line)
        
        try:
            common.ensure_dir(viz_dir)
            print("viz_name:",viz_name)
            # 生成常规可视化结果
            plot_diff(
                test_data, golden_data,
                output_dir=viz_dir,
                filename_prefix=viz_name,
                diff_thd=config.threshold
            )
            # 生成空间分布分析热力图
            plot_spatial_error(
                test_data, golden_data,
                output_dir=viz_dir,
                filename_prefix=viz_name,
                diff_thd=config.threshold
            )
            viz_success_line = f"  可视化结果已保存至: {os.path.abspath(viz_dir)}"
            report_content.append(viz_success_line)
            common.print_log(viz_success_line)
        except Exception as e:
            viz_error_line = f"  可视化生成失败: {e}"
            report_content.append(viz_error_line)
            common.print_log(viz_error_line)
        
        report_content.append(separator)
        common.print_log(separator)
    else:
        report_content.append(viz_title)
        common.print_log(f"{Colors.YELLOW}{viz_title}{Colors.RESET}")
        
        viz_warning_line = "  警告: 可视化功能需要原始测试数据和标杆数据，当前无法生成"
        report_content.append(viz_warning_line)
        common.print_log(viz_warning_line)
        
        report_content.append(separator)
        common.print_log(separator)
    
    # 6. 保存报告到文件
    if viz_dir:
        # 保存文本报告
        report_file = os.path.join(viz_dir, "eco_report.txt")
        try:
            with open(report_file, "w", encoding="utf-8") as f:
                for line in report_content:
                    # 移除控制台颜色代码
                    line = line.replace(Colors.YELLOW, "").replace(Colors.GREEN, "").replace(Colors.RED, "").replace(Colors.RESET, "")
                    f.write(line + "\n")
            common.print_log(f"文本报告已保存至: {os.path.abspath(report_file)}")
        except Exception as e:
            common.print_log(f"保存文本报告失败: {e}")
        
        # 生成HTML报告
        generate_html_report(config, result, viz_dir, report_content, test_data=test_data, viz_name=viz_name)


def generate_html_report(config: EcoBenchConfig, result: EcoMetricResult, output_dir: str, log_content: list, test_data=None, viz_name="spatial"):
    """
    生成HTML格式的精度验证报告
    
    参数:
    - config: 验证配置
    - result: 验证结果
    - output_dir: 报告输出目录
    - log_content: 日志内容列表
    - test_data: 测试数据，用于获取输出形状
    - viz_name: 可视化结果的文件名前缀
    """
    # 读取HTML模板
    template_path = os.path.join(os.path.dirname(__file__), "eco_template_report.html")
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            template = f.read()
    except Exception as e:
        common.print_log(f"读取HTML模板失败: {e}")
        return
    
    # 获取实际输出形状
    output_shape = "[N, C, H, W]"  # 默认值
    if test_data is not None:
        try:
            output_shape = str(tuple(test_data.shape))
        except Exception as e:
            pass
    
    # 准备替换内容
    replacements = {
        "{{OPERATOR_NAME}}": "自定义算子",  # 暂时使用默认值，后续可以扩展
        "{{DATA_TYPE}}": config.dtype_key.upper(),  # 使用大写数据类型名，与单标杆文档一致
        "{{OUTPUT_SHAPE}}": output_shape,  # 使用实际输出形状
        "{{HARDWARE_PLATFORM}}": "Ascend",  # 暂时使用默认值，后续可以扩展
        "{{SOFTWARE_VERSION}}": "未知",  # 暂时使用默认值，后续可以扩展
        "{{REFERENCE_PLATFORM}}": "CPU",  # 暂时使用默认值，后续可以扩展
        "{{TEST_TOOL}}": "CT工具生态算子精度验证",
        "{{DATA_GENERATION}}": "随机生成",  # 暂时使用默认值，后续可以扩展
        "{{DATA_DISTRIBUTION}}": "均匀分布",  # 暂时使用默认值，后续可以扩展
        "{{DATA_SIZE}}": str(result.total_samples),
        "{{DATA_RANGE}}": "[0, 1]",  # 暂时使用默认值，后续可以扩展
        "{{MERE_VALUE}}": f"{result.mere:.6e}",
        "{{MARE_VALUE}}": f"{result.mare:.6e}",
        "{{THRESHOLD}}": f"{config.threshold:.6e}",
        "{{TEN_TIMES_THRESHOLD}}": f"{config.ten_times_threshold:.6e}",
        "{{MERE_CHECK_STATUS}}": "✅" if result.mere < config.threshold else "❌",
        "{{MARE_CHECK_STATUS}}": "✅" if result.mare < config.ten_times_threshold else "❌",
        "{{FINAL_STATUS}}": "PASS" if result.pass_status else "FAIL",
        "{{FINAL_STATUS_CLASS}}": "status-pass" if result.pass_status else "status-fail",
        "{{FINAL_CONCLUSION}}": "精度验证通过" if result.pass_status else "精度验证失败",
        "{{TOTAL_SAMPLES}}": str(result.total_samples),
        "{{AVG_ERROR}}": f"{result.mere:.6e}",  # 使用MERE作为平均误差
        "{{MEDIAN_ERROR}}": "未知",  # 暂时使用默认值，后续可以扩展
        "{{MIN_ERROR}}": "未知",  # 暂时使用默认值，后续可以扩展
        "{{MAX_ERROR}}": f"{result.mare:.6e}",  # 使用MARE作为最大误差
        "{{STD_DEV}}": "未知",  # 暂时使用默认值，后续可以扩展
        "{{HEATMAP_IMAGE_URL}}": f"{viz_name}_spatial_bias.png",  # 根据viz_name生成正确的图片文件名
        "{{CONCLUSION_1}}": "算子精度验证结果：" + ("通过" if result.pass_status else "未通过"),
        "{{CONCLUSION_2}}": f"平均相对误差(MERE)为{result.mere:.6e}，{'小于' if result.mere < config.threshold else '大于等于'}阈值{config.threshold:.6e}",
        "{{CONCLUSION_3}}": f"最大相对误差(MARE)为{result.mare:.6e}，{'小于' if result.mare < config.ten_times_threshold else '大于等于'}10×阈值{config.ten_times_threshold:.6e}",
    }
    
    # 根据测试结果设置不同的建议
    if result.pass_status:
        replacements.update({
            "{{RECOMMENDATION_1}}": "算子精度验证通过，建议继续进行性能测试和其他功能验证",
            "{{RECOMMENDATION_2}}": "建议使用更多不同类型的测试数据进行验证，确保结果稳定性",
            "{{RECOMMENDATION_3}}": "可以考虑进一步优化算子性能，在保持精度的同时提高计算效率"
        })
    else:
        replacements.update({
            "{{RECOMMENDATION_1}}": "由于精度验证未通过，建议重点检查算子实现，特别是可能导致大误差的计算步骤",
            "{{RECOMMENDATION_2}}": "结合第6.2节的空间分布热力图，分析误差较大的区域，查找异常值出现的规律",
            "{{RECOMMENDATION_3}}": "热力图中颜色较深的区域表示误差较大，建议关注这些区域的计算逻辑，针对性地进行优化"
        })
    
    # 替换模板中的占位符
    html_content = template
    for placeholder, value in replacements.items():
        html_content = html_content.replace(placeholder, value)
    
    # 保存HTML报告
    html_file = os.path.join(output_dir, "eco_report.html")
    try:
        with open(html_file, "w", encoding="utf-8") as f:
            f.write(html_content)
        common.print_log(f"HTML报告已保存至: {os.path.abspath(html_file)}")
    except Exception as e:
        common.print_log(f"保存HTML报告失败: {e}")

def show_eco_tips():
    """
    打印生态算子精度验证使用说明
    """
    separator = "=" * ConstConfig.MAX_LEN_SINGLE_HELP
    divider = "-" * ConstConfig.MAX_LEN_SINGLE_HELP
    
    common.print_log(separator)
    title = "生态算子精度验证使用说明"
    common.print_log(f" {title:^{ConstConfig.MAX_LEN_SINGLE_HELP - 12}} ")
    common.print_log(divider)
    
    # 1. 验证标准
    common.print_log(f"{Colors.YELLOW}[验证标准]:{Colors.RESET}")
    common.print_log("  生态算子开源精度标准采用平均相对误差(MERE)和最大相对误差(MARE)指标")
    common.print_log("  通过条件:")
    common.print_log("    - MERE < 阈值")
    common.print_log("    - MARE < 10×阈值")
    common.print_log(divider)
    
    # 2. 阈值表
    common.print_log(f"{Colors.YELLOW}[数据类型阈值表]:{Colors.RESET}")
    
    # 创建阈值表格
    col_widths = [15, 12, 30]
    table = TablePrinter(col_widths, indent=1)
    table.add_row("数据类型", "阈值", "描述")
    table.add_separator()
    
    for dtype, cfg in ECO_DTYPE_CONFIGS.items():
        threshold = cfg["threshold"]
        desc = cfg["desc"]
        table.add_row(dtype, f"{threshold:.6e}", desc)
    
    table.print(common.print_log)
    common.print_log(divider)
    
    # 3. 使用示例
    common.print_log(f"{Colors.YELLOW}[使用示例]:{Colors.RESET}")
    common.print_log("  命令行使用:")
    common.print_log("    ct eco test_data.npy golden_data.npy --dtype float16")
    common.print_log("    ct eco test_data.npy golden_data.npy --dtype float32 --threshold 1e-4")
    common.print_log("    ct eco test_data.npy golden_data.npy --viz --out_dir ./eco_viz")
    common.print_log("  ")
    common.print_log("  脚本调用:")
    common.print_log("    from ct import eco")
    common.print_log("    result = eco(test_data, golden_data, dtype='float16', viz=True)")
    common.print_log(separator)


# ==========================================
# 独立测试函数（可直接运行此文件进行测试）
# ==========================================
if __name__ == "__main__":
    """
    直接测试生态算子精度验证功能
    可以通过运行 python eco_benchmark.py 来测试
    """
    import numpy as np
    import os
    
    print("🔍 直接测试生态算子精度验证功能")
    print("=" * 80)
    
    # 生成测试数据
    shape = (1024, 1024)
    dtype = np.float32
    noise_level = 1e-7
    
    print(f"\n📊 生成数据: 形状={shape}, 数据类型={dtype.__name__}, 噪声水平={noise_level}")
    
    # 生成标杆数据
    golden_data = np.random.rand(*shape).astype(dtype)
    
    # 生成带有噪声的测试数据
    noise = np.random.normal(0, noise_level, shape).astype(dtype)
    test_data = golden_data + noise
    
    print("\n🔧 执行精度验证...")
    
    try:
        # 1. 解析配置
        from argparse import Namespace
        mock_args = Namespace(
            dtype='float32',
            threshold=None,
            small_val_thd=None
        )
        
        config = resolve_eco_config(dtype='float32', args=mock_args)
        print(f"✅ 配置解析完成: 数据类型={config.dtype_key}, MERE阈值={config.threshold:.6e}")
        
        # 2. 创建验证器并执行验证
        validator = EcoBenchmarkValidator(config)
        result = validator.compare(test_data, golden_data)
        print(f"✅ 精度验证完成")
        
        # 3. 创建输出目录
        out_dir = './eco_benchmark_test'
        os.makedirs(out_dir, exist_ok=True)
        print(f"✅ 输出目录已创建: {os.path.abspath(out_dir)}")
        
        # 4. 生成报告
        print("\n📋 生成精度验证报告...")
        print_eco_report(
            config, 
            result, 
            test_data=test_data, 
            golden_data=golden_data, 
            show_viz=True,
            viz_dir=out_dir,
            viz_name="eco_test"
        )
        
        # 5. 检查报告文件
        if os.path.exists(out_dir):
            print(f"\n✅ 报告目录已创建: {os.path.abspath(out_dir)}")
            report_file = os.path.join(out_dir, "eco_report.txt")
            if os.path.exists(report_file):
                print(f"✅ 报告文件已生成: {os.path.abspath(report_file)}")
            else:
                print("❌ 报告文件未生成")
        else:
            print("❌ 报告目录未创建")
            
        # 显示关键结果
        print("\n📋 关键验证结果:")
        print(f"   - 样本总数: {result.total_samples}")
        print(f"   - 平均相对误差(MERE): {result.mere:.6e}")
        print(f"   - 最大相对误差(MARE): {result.mare:.6e}")
        print(f"   - 验证结果: {'PASS' if result.pass_status else 'FAIL'}")
        
    except Exception as e:
        print(f"\n❌ 执行精度验证失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n🎉 测试完成!")