import os
import math
import numpy as np
import torch
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Tuple, Dict, Optional, Union
from ct.utils import common
from ct.utils.common import Colors
from ct.utils.common import ConstConfig
from ct.utils.table import TablePrinter

# ==========================================
# 1. 物理属性配置表
# ==========================================

# A. 小值域阈值 (Small Value Threshold)
# 依据: 数据类型 -> 绝对值界限
SMALL_VALUE_THRESHOLDS = {
    "float16":      2**(-11),
    "bfloat16":     2**(-8),
    "float32":      2**(-14),
    "hifloat32":    2**(-12), # 特殊类型
    "float8_e4m3":  2**(-4),
    "float8_e5m2":  2**(-3)
}

# B. 误差阈值 err 查找表
# 逻辑: 根据 dtype 和 计算次数(count) 返回 err
def get_dynamic_error_threshold(dtype_key: str, count: int) -> float:
    """
    根据数据类型和计算次数(accum_count)获取允许的误差阈值 err
    """
    if dtype_key == "float16":
        if count < 2048: return 2**(-8)
        else:            return 2**(-7)
        
    elif dtype_key == "bfloat16":
        if count < 2048: return 2**(-7)
        else:            return 2**(-6)
        
    elif dtype_key == "float32":
        if count < 2048:   return 2**(-11)
        elif count < 16384: return 2**(-10)
        else:              return 2**(-9)
        
    elif dtype_key == "hifloat32":
        # 假设遵循 float32 或自定义，此处若无具体规则暂时fallback到float32
        # 若有具体规则需在此补充，暂时沿用float32逻辑
        if count < 2048: return 2**(-11)
        else:            return 2**(-10) # 示例

    elif "float8" in dtype_key:
        # 极低精度，假设一个较宽的err，或者根据实际需求补充
        return 2**(-2) 

    # 默认兜底
    return 2**(-10)

# C. 类型映射
DTYPE_MAP = {
    np.float32: "float32", np.float16: "float16",
    torch.float32: "float32", torch.float16: "float16", torch.bfloat16: "bfloat16",
    "fp32": "float32", "fp16": "float16", "bf16": "bfloat16",
    "hifp32": "hifloat32", "fp8_e4m3": "float8_e4m3", "fp8_e5m2": "float8_e5m2"
}

def print_single_benchmark_table():

    # 注意：列宽是指"显示宽度"。
    # "计算次数 (N)" 包含了：
    # 4个汉字(8宽) + 1个空格(1宽) + 3个符号(3宽) = 总共 12 宽。
    # 所以中间列至少要设为 12 以上，这里设为 17 足够宽。
    # 1. 添加表头
    table = TablePrinter([10, 17, 10, 26], indent=2)
    table.add_row("Dtype", "计算次数 (N)", "阈值 (err)", "小值域阈值 (Small_Val_Thd)")
    table.add_separator() # 表头分隔线
    
    # 2. 添加数据 - FLOAT16
    table.add_row("FLOAT16", "N < 2048", "2^-8", "2^-11")
    table.add_row("", "N >= 2048", "2^-7", "")
    table.add_separator()
    
    # 3. 添加数据 - BFLOAT16
    table.add_row("BFLOAT16", "N < 2048", "2^-7", "2^-8")
    table.add_row("", "N >= 2048", "2^-6", "")
    table.add_separator()
    
    # 4. 添加数据 - FLOAT32
    table.add_row("", "N < 2048", "2^-11", "")
    table.add_row("FLOAT32", "2048<=N<16384", "2^-10", "2^-14") # 注意: 稍微缩短了文本以适应17宽
    table.add_row("", "N >= 16384", "2^-9", "")

    # 5. 执行打印
    table.print(common.print_log)

# ==========================================
# 2. 核心配置类
# ==========================================

@dataclass
class SingleBenchConfig:
    """单标杆动态阈值配置"""
    dtype_key: str
    calc_count: int
    
    # 自动计算出的阈值
    small_val_thd: float
    dynamic_err_thd: float

def resolve_single_config(dtype: Union[str, np.dtype, torch.dtype], args=None) -> SingleBenchConfig:
    """
    工厂函数：根据 Dtype 和 Args中的计算次数生成配置
    """
    # 1. 解析 dtype
    dtype_key = "float32"
    if isinstance(dtype, str):
        dtype_key = DTYPE_MAP.get(dtype.lower(), dtype.lower())
    else:
        dtype_key = DTYPE_MAP.get(dtype, "float32")
    
    # 2. 解析计算次数 (默认为1，即Element-wise操作；如果是矩阵乘，需要用户传入)
    calc_count = 1
    if args is not None and hasattr(args, 'calc_count') and args.calc_count is not None:
        calc_count = int(args.calc_count)
    elif args is not None and hasattr(args, 'seq_len'): 
        # 有些场景用 seq_len 近似计算深度
        calc_count = int(args.seq_len)
    
    # 3. 获取阈值
    # 小值域界限
    sv_thd = SMALL_VALUE_THRESHOLDS.get(dtype_key, 2**(-14))
    # 动态误差 err
    err_thd = get_dynamic_error_threshold(dtype_key, calc_count)

    return SingleBenchConfig(
        dtype_key=dtype_key,
        calc_count=calc_count,
        small_val_thd=sv_thd,
        dynamic_err_thd=err_thd
    )

def show_single_tips():
    """打印单标杆精度验收标准说明"""
    separator = "=" * ConstConfig.MAX_LEN_SINGLE_HELP
    divider = "-" * ConstConfig.MAX_LEN_SINGLE_HELP

    common.print_log(separator)
    # 动态居中标题
    title = "单标杆精度验收标准"
    common.print_log(f" {title:^{ConstConfig.MAX_LEN_SINGLE_HELP - 12}} ")
    common.print_log(divider)

    # 1. 标杆生成
    common.print_log(f"{Colors.YELLOW}[标杆生成]:{Colors.RESET}")
    common.print_log(" 标杆数据采用高精度实现:")
    common.print_log("    a. 输入数据：FP16/BF16/FP8 -> 转 FP32 计算   -> 输出 FP32")
    common.print_log("    b. 输入数据：FP32/HiFP8    -> 直接 FP32 计算 -> 输出 FP32")
    common.print_log(" 注：若怀疑标杆结果精度低，可采用FP64重新生成标杆自证")
    common.print_log(divider)

    # 2. 判定公式
    common.print_log(f"{Colors.YELLOW}[数值精度判定标准]:{Colors.RESET}")
    common.print_log(" 通过判定公式:")
    common.print_log(f"   {Colors.CYAN}|actual - golden| <= err * max(Small_Val_Thd, |golden|){Colors.RESET}")
    common.print_log("   小值阈值 (Small_Val_Thd): 根据 dtype 自动获取 (如 FP16=2^(-11), FP32=2^(-14) 等)")
    common.print_log("   逻辑解释:")
    common.print_log("      |golden| >= Small_Val_Thd: 执行相对误差判定 (RE)")
    common.print_log("      |golden| <  Small_Val_Thd: 执行绝对误差判定 (AE)")

    common.print_log(divider)

    # 3. 动态阈值表 (核心新增内容)
    common.print_log(f"{Colors.YELLOW}[误差 & 小值域阈值表 (err & Small_Val_Thd)]: {Colors.RESET}根据计算次数(Calc Count)分档")
    
    print_single_benchmark_table()

    common.print_log(divider)
    # 3. 边界值判定公式
    common.print_log(f"{Colors.YELLOW}[Inf/NaN 判定标准]:{Colors.RESET}")
    common.print_log(" 标杆含 Inf/NaN: 测试用例无效")
    common.print_log(" NPU含 Inf/NaN (标杆正常):")
    common.print_log("    a. NPU输出 FP16:      若标杆值超出FP16表示范围 -> 豁免(Pass); 否则 -> 失败")
    common.print_log("    b. NPU输出 FP32/BF16: 视为算子问题 -> 失败")
    
    common.print_log(divider) # 最外层分割线

    # 4. 参数说明
    common.print_log(f"{Colors.YELLOW}[参数使用说明]:{Colors.RESET}")

    common.print_log(f" {'1.--calc_count:':<17}算子计算深度。决定查表使用哪个 err 阈值。")
    common.print_log(f" {'':<19}例如: MatMul可填K轴大小。默认按 N<2048 处理。")
    common.print_log(f" {'2.--thd:':<17}支持手动覆盖 Small_Val_Thd。")
    common.print_log(f" {'3.--dtype:':<17}支持手动覆盖 dtype。")

    common.print_log(divider)

    # 5. 示例
    common.print_log(f"{Colors.YELLOW}[使用示例]:{Colors.RESET}")
    common.print_log(" 1. 基础比对:     <ct single actual.npy golden.npy>")
    common.print_log(" 2. 指定计算次数: <ct single act.npy gold.npy --calc_count 4096>")
    common.print_log(" 3. 强制指定类型: <ct single act.npy gold.npy --dtype float16>")

    common.print_log(divider)

    # 6. 示例
    common.print_log(f"{Colors.YELLOW}[脚本调用示例]:{Colors.RESET}")
    common.print_log("  import sys")
    common.print_log("  import numpy as np")
    common.print_log("  from ct import single")
    common.print_log("  shape = (1024, 1024)")
    common.print_log("  data_real = np.random.rand(*shape).astype(np.float32)")
    common.print_log("  # 制造微小误差")
    common.print_log("  data_expect = data_real + np.random.normal(0, 1e-5, shape).astype(np.float32)")
    common.print_log("  # 调用 single")
    common.print_log("  result = single(")
    common.print_log("      test=data_real,        # 待测数据")
    common.print_log("      golden=data_expect,    # 标杆数据")
    common.print_log("      # --- 核心配置 ---")
    common.print_log("      calc_count=1,          # 计算量/累加深度 (默认: 1)")
    common.print_log("      dtype=None,            # 数据类型 (默认: None)")
    common.print_log("      out_dir=\"ct/single_result\", # 输出目录 (默认: ct/single_result)")
    common.print_log("      # --- 高级阈值 (Kwargs), 默认为 None ---")
    common.print_log("      small_val_thd=None,")
    common.print_log("      small_val_err_thd=None")
    common.print_log("  )")
    common.print_log(separator)

# ==========================================
# 3. 验证器类
# ==========================================

@dataclass
class SingleMetricResult:
    total_points: int
    fail_count: int
    pass_rate: float
    max_diff: float  # 最大的绝对误差
    max_re_calc: float # 按照公式计算出的最大 RE (大值域)

class SingleBenchmarkValidator:
    def __init__(self, config: SingleBenchConfig):
        self.cfg = config
    
    def compare(self, test_data: np.ndarray, golden_data: np.ndarray) -> Dict:
        """
        核心比对函数：执行逐点校验
        """
        # 转为高精度计算
        actual = np.array(test_data, dtype=np.float64).flatten()
        golden = np.array(golden_data, dtype=np.float64).flatten()
        
        # 0. 基础准备
        abs_golden = np.abs(golden)
        diff = np.abs(actual - golden)
        err_thd = self.cfg.dynamic_err_thd
        sv_thd = self.cfg.small_val_thd

        # 1. 划分区域
        # Mask Large: 绝对值 >= 小值域阈值
        mask_large = abs_golden >= sv_thd
        # Mask Small: 绝对值 < 小值域阈值
        mask_small = ~mask_large

        # 2. 判定逻辑
        
        # --- Case A: 大值域 (使用修正后的相对误差公式) ---
        # 规则: RE = diff / (abs(golden) + 1e-7) <= err
        # 向量化计算 RE
        # 避免全量计算，只计算 mask_large 部分，这里为了代码清晰全量算，只取 mask
        re_denominator = abs_golden + 1e-7
        re_values = diff / re_denominator
        
        # 找出大值域中的失败点
        # 条件: 是大值 且 RE > err
        fail_large_mask = mask_large & (re_values > err_thd)

        # --- Case B: 小值域 (使用绝对误差) ---
        # 规则: AE = diff <= err
        # 找出小值域中的失败点
        # 条件: 是小值 且 AE > err
        fail_small_mask = mask_small & (diff > err_thd)

        # 3. 汇总结果
        total_fail_mask = fail_large_mask | fail_small_mask
        fail_count = np.sum(total_fail_mask)
        total_points = actual.size
        
        # 4. 计算统计指标 (仅供参考)
        max_diff = np.max(diff) if total_points > 0 else 0.0
        # 计算大值域里的最大RE用于展示
        if np.any(mask_large):
            max_re_calc = np.max(re_values[mask_large])
        else:
            max_re_calc = 0.0

        metrics = SingleMetricResult(
            total_points=int(total_points),
            fail_count=int(fail_count),
            pass_rate=100.0 * (total_points - fail_count) / max(1, total_points),
            max_diff=float(max_diff),
            max_re_calc=float(max_re_calc)
        )

        # 判定: 要求失败数为 0 才算完全通过 (Strict Mode)
        # 如果需要允许少量误差，可以修改此处逻辑，例如 fail_count / total < 0.001
        is_success = (fail_count == 0)

        checks = {
            "all_pass": is_success,
            "err_threshold_used": err_thd
        }

        return {
            "success": is_success,
            "metrics": metrics,
            "checks": checks,
            "fail_mask": total_fail_mask, # 供绘图用
            "diff_data": diff # 供绘图用
        }

    @staticmethod
    def plot_failure_heatmap(fail_mask, shape, save_path):
        """绘制失败点分布图"""
        if np.sum(fail_mask) == 0:
            return
        
        try:
            # 尝试还原形状，如果是扁平的，尝试凑个方阵
            if len(shape) >= 2:
                # 取前两个维度或切片
                h, w = shape[0], shape[1]
                data_2d = fail_mask.reshape(shape).astype(float)
                if len(shape) > 2: # 比如 (N, C, H, W)，只画第一张图
                    data_2d = data_2d.flatten()[:h*w].reshape(h, w)
            else:
                side = int(np.sqrt(fail_mask.size))
                data_2d = fail_mask[:side*side].reshape(side, side).astype(float)

            plt.figure(figsize=(10, 8))
            # 失败点显示为红色 (1)，成功为蓝色 (0)
            plt.imshow(data_2d, cmap='coolwarm', interpolation='nearest') 
            plt.colorbar(label='0: Pass, 1: Fail')
            plt.title(f"Failure Distribution (Total Fails: {np.sum(fail_mask)})")
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            plt.savefig(save_path, dpi=150)
            plt.close()
            common.print_log(f"失败分布图已保存至: {save_path}")
        except Exception as e:
            common.print_log(f"[Plot Warning] Skip heatmap: {e}")

def print_single_report(final_cfg: SingleBenchConfig, result):
    """
    打印结果报告
    """
    m = result['metrics']
    separator = "=" * ConstConfig.MAX_LEN_SINGLE_REPORT
    divider = "-" * ConstConfig.MAX_LEN_SINGLE_REPORT
    
    common.print_log(separator)
    common.print_log(f"单标杆测试报告")
    common.print_log(divider)
    
    # 1. 配置回显
    common.print_log(f"{Colors.YELLOW}[配置信息]:{Colors.RESET}")
    common.print_log(f"  待测数据类型: {final_cfg.dtype_key}")
    common.print_log(f"  计算次数:     {final_cfg.calc_count}")
    common.print_log(f"  小值域阈值:   {final_cfg.small_val_thd}")
    common.print_log(f"  错误阈值限制: {final_cfg.dynamic_err_thd}")
    common.print_log(divider)
    
    common.print_log(f"{Colors.YELLOW}[检查说明]:{Colors.RESET}")
    common.print_log(f"  当标杆值 < {final_cfg.small_val_thd} 被视为{Colors.CYAN}小值域{Colors.RESET}数据")
    common.print_log(f"  小值域数据要求{Colors.CYAN}绝对误差{Colors.RESET}（AE）≤ {final_cfg.dynamic_err_thd}")
    common.print_log(f"  非小值域数据要求{Colors.CYAN}相对误差{Colors.RESET}（RE）≤ {final_cfg.dynamic_err_thd}")
    common.print_log(divider)

    status_str = "PASS" if result['success'] else "FAIL"
    status_color = f"{Colors.GREEN}PASS{Colors.RESET}" if result['success'] else f"{Colors.RED}FAIL{Colors.RESET}"
    
    # 2. 统计数据
    common.print_log(f"{Colors.YELLOW}[对比结果]:{Colors.RESET} {status_color}")
    
    common.print_log(f"  总样本点数:   {m.total_points}")
    common.print_log(f"  失败样本点数: {m.fail_count}")
    
    # 颜色高亮通过率
    rate_color = Colors.GREEN if m.pass_rate == 100.0 else Colors.RED
    common.print_log(f"  通过率:       {rate_color}{m.pass_rate:.6f} %{Colors.RESET}")
    
    common.print_log(f"  最大绝对误差: {m.max_diff:.8f}")
    common.print_log(f"  最大相对误差: {m.max_re_calc:.8f}")
    common.print_log(separator)