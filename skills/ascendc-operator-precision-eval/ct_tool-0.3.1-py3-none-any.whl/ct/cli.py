import argparse
import numpy as np
import torch
import os
from typing import Any, Dict, Union
from dataclasses import dataclass

# 内部工具导入
from ct.utils.common import print_log, print_config_semantics
from .isclose import _isclose_impl, save_compare_report 
from .docgen import generate_design_doc_template
from .viz import plot_diff, plot_spatial_error
from .dual_compare import (
    DualBenchmarkValidator, 
    resolve_dual_config,
    print_dual_report,
    show_dual_tips,
    process_excel_and_check
)
from .single_compare import (
    SingleBenchmarkValidator,
    resolve_single_config,
    print_single_report,
    show_single_tips
)
from .eco_compare import (
    EcoBenchmarkValidator,
    resolve_eco_config,
    print_eco_report,
    show_eco_tips
)

def _to_numpy(tensor):
    """辅助函数：安全地将 Tensor 转换为 Numpy"""
    if tensor.dtype == torch.bfloat16:
        return tensor.float().numpy()  # bfloat16 先转 float32
    return tensor.numpy()


def _load_or_pass(data):
    """辅助函数：加载文件或直接返回数据"""
    if isinstance(data, (str, bytes)):
        # 是路径，尝试加载
        ext = os.path.splitext(data)[-1].lower()
        if ext in [".npy"]:
            return np.load(data, allow_pickle=False)
        elif ext in [".pt", ".pth"]:
            tensor = torch.load(data, map_location="cpu")
            return _to_numpy(tensor)
        else:
            raise ValueError(f"Unsupported file extension: {ext}")
    elif isinstance(data, torch.Tensor):
        # 是 torch.Tensor，转 numpy
        return _to_numpy(data)
    elif isinstance(data, np.ndarray):
        # 已经是 numpy，直接返回
        return data
    else:
        raise TypeError(f"Unsupported data type: {type(data)}")


# ==========================================
# CLI 命令实现
# ==========================================

# --- Command 1: isclose (单标杆/绝对比较) ---
def isclose(real, expect, diff_thd=0.001, pct_thd=0.001, max_diff_hd=0):
    """
    脚本调用接口: 单标杆/绝对比较
    """
    real_data = _load_or_pass(real)
    expect_data = _load_or_pass(expect)
    
    result_dict = _isclose_impl(real_data, expect_data, diff_thd, pct_thd, max_diff_hd)
    save_compare_report(result_dict, real_data, expect_data)
    return result_dict


# --- Command 2: viz (可视化) ---
def viz(real, expect, out_dir="ct/viz_result", name="diff_viz", diff_thd=0.001, spatial=False):
    """
    脚本调用接口: 可视化
    """
    real_data = _load_or_pass(real)
    expect_data = _load_or_pass(expect)
    
    # 基本可视化
    plot_diff(real_data, expect_data, output_dir=out_dir, filename_prefix=name, diff_thd=diff_thd)
    
    # 空间热力图 (可选)
    if spatial:
        plot_spatial_error(real_data, expect_data, output_dir=out_dir, filename_prefix=name)
    
    print_log(f"Visualization completed. Output saved to {os.path.abspath(out_dir)}")


# --- Command 3: dual (双标杆比较) ---
def dual(test, gt, bench, level="L1", dtype=None, out_dir="ct/dual_result", **kwargs):
    """
    脚本调用接口: 双标杆比较
    """
    # 加载数据
    test_data = _load_or_pass(test)
    gt_data = _load_or_pass(gt)
    bench_data = _load_or_pass(bench)
    
    # 处理 dtype
    current_dtype = test_data.dtype if dtype is None else dtype
    
    # 创建配置
    mock_args = argparse.Namespace(
        level=level,
        MARE_ratio_thd=kwargs.get("MARE_ratio_thd"),
        MERE_ratio_thd=kwargs.get("MERE_ratio_thd"),
        RMSE_ratio_thd=kwargs.get("RMSE_ratio_thd"),
        ERR_COUNT_ratio_thd=kwargs.get("ERR_COUNT_ratio_thd"),
        small_val_thd=kwargs.get("small_val_thd"),
        small_val_err_thd=kwargs.get("small_val_err_thd"),
    )
    config = resolve_dual_config(mock_args)
    
    # 执行验证
    validator = DualBenchmarkValidator(config)
    result = validator.compare(test_data, gt_data, bench_data)
    
    # 生成报告
    print_dual_report(config, result, save_chart=kwargs.get("save_chart", False), out_dir=out_dir)
    
    return result


# --- Command 4: single (单标杆比较) ---
def single(test, golden, calc_count=1, dtype=None, out_dir="ct/single_result", **kwargs):
    """
    脚本调用接口: 单标杆比较
    """
    test_data = _load_or_pass(test)
    golden_data = _load_or_pass(golden)
    
    current_dtype = test_data.dtype if dtype is None else dtype
    
    # 模拟 args
    mock_args = argparse.Namespace(
        calc_count=calc_count,
        dtype=dtype,
        out_dir=out_dir,
        small_val_thd=kwargs.get('small_val_thd'),
        small_val_err_thd=kwargs.get('small_val_err_thd')
    )

    final_cfg = resolve_single_config(args=mock_args, dtype=current_dtype)
    validator = SingleBenchmarkValidator(final_cfg)
    result = validator.compare(test_data, golden_data)
    
    print_single_report(final_cfg, result)
    return result


# --- Command 5: eco (生态算子精度验证) ---
def eco(test, golden, dtype=None, threshold=None, small_val_thd=None, out_dir="ct/eco_result", viz=True, viz_name="eco_viz", **kwargs):
    """
    脚本调用接口: 生态算子精度验证
    """
    test_data = _load_or_pass(test)
    golden_data = _load_or_pass(golden)
    
    current_dtype = test_data.dtype if dtype is None else dtype
    
    # 模拟 args
    mock_args = argparse.Namespace(
        dtype=dtype,
        threshold=threshold,
        small_val_thd=small_val_thd
    )

    final_cfg = resolve_eco_config(dtype=current_dtype, args=mock_args)
    validator = EcoBenchmarkValidator(final_cfg)
    result = validator.compare(test_data, golden_data)
    
    print_eco_report(final_cfg, result, test_data=test_data, golden_data=golden_data, show_viz=viz, viz_dir=out_dir, viz_name=viz_name)
    return result


# ==========================================
# 主函数
# ==========================================
def main():
    parser = argparse.ArgumentParser(description="CT Tool CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    subparser_map = {}
    
    # === Command 1: ct isclose (单标杆/绝对比较) ===
    parser_isclose = subparsers.add_parser('isclose', help="单标杆/绝对比较")
    subparser_map['isclose'] = parser_isclose  # <--- 存入 map
    parser_isclose.add_argument("real", type=str, help="待测数据的路径")
    parser_isclose.add_argument("expect", type=str, help="标杆数据的路径")
    parser_isclose.add_argument("--diff_thd", type=float, default=0.001, help="绝对误差阈值")
    parser_isclose.add_argument("--pct_thd", type=float, default=0.001, help="相对误差阈值")
    parser_isclose.add_argument("--max_diff_hd", type=int, default=0, help="高位差阈值")
    
    # === Command 2: ct docgen (生成设计文档模板) ===
    parser_docgen = subparsers.add_parser('docgen', help="生成设计文档模板")
    subparser_map['docgen'] = parser_docgen  # <--- 存入 map
    parser_docgen.add_argument("--name", type=str, default="sample", help="算子名称")
    parser_docgen.add_argument("--out", type=str, default=".", help="输出目录")
    
    # === Command 3: ct viz (生成误差分布可视化图表) ===
    parser_viz = subparsers.add_parser('viz', help="生成误差分布可视化图表")
    subparser_map['viz'] = parser_viz  # <--- 存入 map
    parser_viz.add_argument("real", type=str, help="待测数据的路径")
    parser_viz.add_argument("expect", type=str, help="标杆数据的路径")
    parser_viz.add_argument("--out_dir", type=str, default="ct/viz_result", help="可视化结果输出目录")
    parser_viz.add_argument("--name", type=str, default="diff_viz", help="输出文件名前缀")
    parser_viz.add_argument("--diff_thd", type=float, default=0.001, help="误差高亮阈值 (超过此值将被标记)")
    parser_viz.add_argument("--spatial", action="store_true", help="是否启用空间热力图分析")
    
    # === Command 4: ct dual (双标杆比较) ===
    parser_dual = subparsers.add_parser('dual', help="双标杆精度对比")
    subparser_map['dual'] = parser_dual  # <--- 存入 map
    # 修改 help 描述，引导用户使用 'tips' 或 'help'
    parser_dual.add_argument("test", type=str, nargs='?', help="待测数据的路径")
    parser_dual.add_argument("gt", type=str, nargs='?', help="真值数据的路径")
    parser_dual.add_argument("bench", type=str, nargs='?', help="对照数据的路径")
    
    parser_dual.add_argument("--level", type=str, default="L1", choices=["L0", "L1", "L2"], help="预设严格等级 (L0:宽松, L1:标准, L2:严格)")
    parser_dual.add_argument("--MARE_ratio_thd", type=float, default=None, help="最大相对误差(MARE)比例阈值")
    parser_dual.add_argument("--MERE_ratio_thd", type=float, default=None, help="平均相对误差(MERE)比例阈值")
    parser_dual.add_argument("--RMSE_ratio_thd", type=float, default=None, help="均方根误差(RMSE)比例阈值")
    parser_dual.add_argument("--ERR_COUNT_ratio_thd", type=float, default=None, help="小错误点数量比例阈值")
    parser_dual.add_argument("--small_val_thd", type=float, default=None, help="小值过滤阈值")
    parser_dual.add_argument("--small_val_err_thd", type=float, default=None, help="小值区间的允许误差阈值")
    parser_dual.add_argument("--dtype", type=str, default=None, help="强制指定数据类型 (如 float16, float32)")
    parser_dual.add_argument("--save_chart", action="store_true", help="是否保存误差分布统计图")
    parser_dual.add_argument("--out_dir", type=str, default="ct/dual_result", help="结果输出目录")
    
    # === Command 5: ct single ===
    parser_single = subparsers.add_parser('single', help="单标杆精度对比")
    subparser_map['single'] = parser_single  # <--- 存入 map
    parser_single.add_argument("test", type=str, nargs='?', help="待测数据路径")
    parser_single.add_argument("golden", type=str, nargs='?', help="标杆/真值数据路径")
    parser_single.add_argument("--calc_count", type=int, default=1, help="计算量/累加深度 (用于推导动态误差阈值)")
    parser_single.add_argument("--dtype", type=str, default=None, help="强制指定数据类型 (如 float16, float32)")
    parser_single.add_argument("--out_dir", type=str, default="ct/single_result", help="结果输出目录")
    parser_single.add_argument("--small_val_thd", type=float, default=None, help="小值过滤阈值")
    parser_single.add_argument("--small_val_err_thd", type=float, default=None, help="小值区间的允许误差阈值")
    
    # === Command 6: ct eco (生态算子精度验证) ===
    parser_eco = subparsers.add_parser('eco', help="生态算子精度验证")
    subparser_map['eco'] = parser_eco  # <--- 存入 map
    parser_eco.add_argument("test", type=str, nargs='?', help="待测数据路径")
    parser_eco.add_argument("golden", type=str, nargs='?', help="标杆/真值数据路径")
    parser_eco.add_argument("--dtype", type=str, default=None, help="强制指定数据类型 (如 float16, float32, bfloat16)")
    parser_eco.add_argument("--threshold", type=float, default=None, help="手动指定MERE阈值")
    parser_eco.add_argument("--small_val_thd", type=float, default=None, help="小值过滤阈值")
    parser_eco.add_argument("--out_dir", type=str, default="ct/eco_result", help="结果输出目录")
    parser_eco.add_argument("--viz", action="store_true", help="是否生成可视化结果")
    parser_eco.add_argument("--viz_name", type=str, default="eco_viz", help="可视化结果文件名前缀")


    parser.add_argument("--version", action="store_true", help="显示工具版本信息")

    args = parser.parse_args()

    print_config_semantics(args, subparser_map)
    # ================= 逻辑处理 =================

    if args.command == "isclose":
        isclose(args.real, args.expect, 
                diff_thd=args.diff_thd, pct_thd=args.pct_thd, max_diff_hd=args.max_diff_hd)

    elif args.command == "docgen":
        generate_design_doc_template(args.name, args.out)

    elif args.command == "viz":
        viz(args.real, args.expect, 
            out_dir=args.out_dir, name=args.name, 
            diff_thd=args.diff_thd, spatial=args.spatial)

    elif args.command == "dual":
        if args.test in ["tips", "help"]:
            show_dual_tips()
            return
        elif args.test in ["analyze"]:
            process_excel_and_check(args.gt)
            return

        if not args.test or not args.gt or not args.bench:
            print("[Error] Missing file arguments for dual compare.")
            return
            
        dual(args.test, args.gt, args.bench, 
             level=args.level, dtype=args.dtype, 
             save_chart=args.save_chart, out_dir=args.out_dir,
             MARE_ratio_thd=args.MARE_ratio_thd,
             MERE_ratio_thd=args.MERE_ratio_thd,
             RMSE_ratio_thd=args.RMSE_ratio_thd,
             ERR_COUNT_ratio_thd=args.ERR_COUNT_ratio_thd,
             small_val_thd=args.small_val_thd,
             small_val_err_thd=args.small_val_err_thd)

    elif args.command == "single":
        if args.test in ["tips", "help"]:
            show_single_tips()
            return
        if not args.test or not args.golden:
            print("[Error] Missing file arguments for single compare.")
            return
            
        single(args.test, args.golden, 
               calc_count=args.calc_count, dtype=args.dtype,
               out_dir=args.out_dir,
               small_val_thd=args.small_val_thd,
               small_val_err_thd=args.small_val_err_thd)
                
    elif args.command == "eco":
        if args.test in ["tips", "help"]:
            show_eco_tips()
            return
        if not args.test or not args.golden:
            print("[Error] Missing file arguments for eco compare.")
            return
            
        eco(args.test, args.golden, 
            dtype=args.dtype,
            threshold=args.threshold,
            small_val_thd=args.small_val_thd,
            out_dir=args.out_dir,
            viz=args.viz,
            viz_name=args.viz_name)

    # 其他
    elif args.version:
        print_log("cann-tool version 0.3.1")
        return

    else:
        parser.print_help()

if __name__ == "__main__":
    main()