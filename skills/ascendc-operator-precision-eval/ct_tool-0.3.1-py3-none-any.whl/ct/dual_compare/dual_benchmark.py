import os
import math
import numpy as np
import torch  # 需要导入 torch 以支持 bfloat16 判断
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Tuple, Dict, Optional, Union
from ct.utils import common
from ct.utils.common import Colors
from ct.utils.common import ConstConfig
from ct.utils.table import TablePrinter
from ct.utils.color_ctrl import DualLogger
# ==========================================
# 1. 配置定义 (数据类型 & 等级分离)
# ==========================================

# --- A. 数据类型阈值配置 (物理属性) ---
# 定义不同精度下的“小值域”和“允许误差”
DTYPE_CONFIGS = {
    # FP32 / Float: 高精度标准
    "float32": {
        "small_thd": 2**(-14), 
        "small_err": 2**(-30), 
        "desc": "Standard Precision"
    },
    # FP16 / Half: 精度较低，epsilon 约为 1e-3
    "float16": {
        "small_thd": 2**(-11), 
        "small_err": 2**(-16),  # 误差容忍度放宽到 1e-3
        "desc": "Half Precision"
    },
    # BF16: 动态范围大但精度低 (尾数只有7位)，误差约为 1e-2 级别
    "bfloat16": {
        "small_thd": 2**(-8),  # 小值域范围扩大
        "small_err": 2**(-16),  # 误差容忍度显著放宽
        "desc": "Brain Float 16"
    }
}

# 兼容 numpy 和 torch 的 dtype 映射键值
DTYPE_MAP = {
    np.float32: "float32",
    np.float16: "float16",
    torch.float32: "float32",
    torch.float16: "float16",
    torch.bfloat16: "bfloat16",
    "fp32": "float32",
    "fp16": "float16",
    "bf16": "bfloat16"
}

# --- B. 严格等级预设 (业务标准) ---
# 只保留“比例”相关的阈值，不再包含绝对数值
DUAL_PRESETS = {
    "L0": {
        "desc": "宽松模式:适用于量化/低精度调试",
        "ratio_max": 10.0, "ratio_mean": 2.0, "ratio_rmse": 2.0, "ratio_small": 2.0,
    },
    "L1": {
        "desc": "标准模式:默认推荐，允许微量波动",
        "ratio_max": 5.0, "ratio_mean": 1.5, "ratio_rmse": 1.5, "ratio_small": 2.0,
    },
    "L2": {
        "desc": "严格模式:适用于高精度算子对齐",
        "ratio_max": 2.0, "ratio_mean": 1.2, "ratio_rmse": 1.2, "ratio_small": 2.0,
    }
}

# ==========================================
# 2. 核心配置类
# ==========================================

@dataclass
class DualBenchConfig:
    """双标杆测试阈值配置"""
    # 1. 结果比值通过阈值 (Test指标 / Bench指标 <= 此值)
    ratio_max_re_thd: float
    ratio_mean_re_thd: float
    ratio_rmse_thd: float
    ratio_small_err_count_thd: float

    # 2. 小值域定义 (由 Dtype 决定)
    small_val_thd: float 
    small_val_err_thd: float

def resolve_dual_config(level: str, dtype: Union[str, np.dtype, torch.dtype], args=None) -> DualBenchConfig:
    """
    工厂函数：根据 Level 和 Dtype 生成最终配置，并应用 args 中的覆盖参数
    """
    # 1. 获取 Level 配置
    if level not in DUAL_PRESETS:
        common.print_log(f"[Warning] Unknown level '{level}', utilizing L1 fallback.")
        level = "L1"
    level_cfg = DUAL_PRESETS[level]

    # 2. 获取 Dtype 配置
    dtype_key = "float32" # 默认 fallback
    if isinstance(dtype, str):
        dtype_key = DTYPE_MAP.get(dtype.lower(), dtype.lower())
    else:
        # 处理 numpy 或 torch 的 dtype 对象
        dtype_key = DTYPE_MAP.get(dtype, "float32")
    
    if dtype_key not in DTYPE_CONFIGS:
        dtype_key = "float32"
        
    dtype_cfg = DTYPE_CONFIGS[dtype_key]
    dtype_desc_str = f"{dtype_key}"
    # 3. 创建初始配置对象
    config = DualBenchConfig(
        ratio_max_re_thd=level_cfg["ratio_max"],
        ratio_mean_re_thd=level_cfg["ratio_mean"],
        ratio_rmse_thd=level_cfg["ratio_rmse"],
        ratio_small_err_count_thd=level_cfg["ratio_small"],
        small_val_thd=dtype_cfg["small_thd"],
        small_val_err_thd=dtype_cfg["small_err"]
    )

    # 4. 处理参数覆盖 (Override Logic)
    if args is not None:
        if hasattr(args, 'MARE_ratio_thd') and args.MARE_ratio_thd is not None:
            config.ratio_max_re_thd = args.MARE_ratio_thd
            common.print_log(f"  [Override] MARE_ratio_thd overridden to: {config.ratio_max_re_thd}")

        if hasattr(args, 'MERE_ratio_thd') and args.MERE_ratio_thd is not None:
            config.ratio_mean_re_thd = args.MERE_ratio_thd
            common.print_log(f"  [Override] MERE_ratio_thd overridden to: {config.ratio_mean_re_thd}")

        if hasattr(args, 'RMSE_ratio_thd') and args.RMSE_ratio_thd is not None:
            config.ratio_rmse_thd = args.RMSE_ratio_thd
            common.print_log(f"  [Override] RMSE_ratio_thd overridden to: {config.ratio_rmse_thd}")

        if hasattr(args, 'ERR_COUNT_ratio_thd') and args.ERR_COUNT_ratio_thd is not None:
            config.ratio_small_err_count_thd = args.ERR_COUNT_ratio_thd
            common.print_log(f"  [Override] ERR_COUNT_ratio_thd overridden to: {config.ratio_small_err_count_thd}")

        if hasattr(args, 'small_val_thd') and args.small_val_thd is not None:
            config.small_val_thd = args.small_val_thd
            common.print_log(f"  [Override] small_val_thd overridden to: {config.small_val_thd}")

        if hasattr(args, 'small_val_err_thd') and args.small_val_err_thd is not None:
            config.small_val_err_thd = args.small_val_err_thd
            common.print_log(f"  [Override] small_val_err_thd overridden to: {config.small_val_err_thd}")

    return config, dtype_desc_str

def print_metrics_formula_table():
    """
    打印数值精度指标计算公式表 (使用 TablePrinter)
    """
    # 1. 定义列宽
    # 根据内容长度预估:
    # Col 1: "|y| > Small_Val_Thd" (长约21) -> 设为 26
    # Col 2: "Err_Count" (长约9) -> 设为 12
    # Col 3: 最长公式约 45 字符 -> 设为 32
    col_widths = [26, 12, 32]
    
    # 2. 初始化表格
    table = TablePrinter(col_widths, indent=1)
    
    # 3. 添加表头
    table.add_row("前置条件", "指标类别", "计算公式")
    table.add_separator() # 表头分割线
    
    # 4. 第一组数据 (大值域: MARE, MERE, RMSE)
    # 技巧：为了实现“合并单元格”的视觉效果，我们在第1、3行第一列留空，只在中间行填内容
    
    # 行 1: MARE (第一列空)
    table.add_row(
        "", 
        "MARE", 
        "max( |x - y| / |y| )"
    )
    
    # 行 2: MERE (第一列填内容，视觉居中)
    table.add_row(
        "|y| > Small_Val_Thd", 
        "MERE", 
        "(1/N) * ∑ ( |x - y| / |y| )"
    )
    
    # 行 3: RMSE (第一列空)
    table.add_row(
        "", 
        "RMSE", 
        "√ [ (1/N) * ∑ (x - y)² ]"
    )

    # 5. 添加分割线 (隔开大值域和小值域)
    table.add_separator()

    # 6. 第二组数据 (小值域: Err_Count)
    table.add_row(
        "|y| <= Small_Val_Thd", 
        "Err_Count", 
        "Count( |x - y| > Small_Err_Thd )"
    )

    # 7. 执行打印
    table.print(common.print_log)
    
    # 8. 脚注 (此处可以使用颜色，因为不在 TablePrinter 计算范围内)
    common.print_log(f"   {Colors.GRAY}* 注: x=Actual(待测/标杆), y=Golden(真值), N=数据量{Colors.RESET}")

def print_metrics_ratio_formula_table():
    """
    打印数值精度指标计算公式表 (使用 TablePrinter)
    """
    # 1. 定义列宽
    # 根据内容长度预估:
    # Col 1: "|y| > Small_Val_Thd" (长约21) -> 设为 26
    # Col 2: "Err_Count" (长约9) -> 设为 12
    # Col 3: 最长公式约 45 字符 -> 设为 32
    col_widths = [26, 12, 32]
    
    # 2. 初始化表格
    table = TablePrinter(col_widths, indent=1)
    
    # 3. 添加表头
    table.add_row("指标类别", "计算公式", "防除零")
    table.add_separator() # 表头分割线
    
    # 4. 第一组数据 (大值域: MARE, MERE, RMSE)
    # 技巧：为了实现“合并单元格”的视觉效果，我们在第1、3行第一列留空，只在中间行填内容
    
    # 行 1: MARE (第一列空)
    table.add_row(
        "", 
        "MARE", 
        "max( |x - y| / |y| )"
    )
    
    # 行 2: MERE (第一列填内容，视觉居中)
    table.add_row(
        "|y| > Small_Val_Thd", 
        "MERE", 
        "(1/N) * ∑ ( |x - y| / |y| )"
    )
    
    # 行 3: RMSE (第一列空)
    table.add_row(
        "", 
        "RMSE", 
        "√ [ (1/N) * ∑ (x - y)² ]"
    )

    # 5. 添加分割线 (隔开大值域和小值域)
    table.add_separator()

    # 6. 第二组数据 (小值域: Err_Count)
    table.add_row(
        "|y| <= Small_Val_Thd", 
        "Err_Count", 
        "Count( |x - y| > Small_Err_Thd )"
    )

    # 7. 执行打印
    table.print(common.print_log)
    
    # 8. 脚注 (此处可以使用颜色，因为不在 TablePrinter 计算范围内)
    common.print_log(f"   {Colors.GRAY}* 注: x=Actual(待测/标杆), y=Golden(真值), N=数据量{Colors.RESET}")

def print_dual_presets_table(DUAL_PRESETS):

    # 1. 定义列宽
    # 根据表头文字长度估算:
    # "Level" (5) -> 设为 7
    # "MARE_ratio_thd" (14) -> 设为 15
    # "MERE_ratio_thd" (14) -> 设为 15
    # "RMSE_ratio_thd" (14) -> 设为 15
    # "ERR_COUNT_ratio_thd" (19) -> 设为 19
    col_widths = [5, 15, 15, 15, 19]
    
    # 2. 初始化表格
    table = TablePrinter(col_widths, indent=1)
    
    # 3. 添加表头
    table.add_row(
        "Level", 
        "MARE_ratio_thd", 
        "MERE_ratio_thd", 
        "RMSE_ratio_thd", 
        "ERR_COUNT_ratio_thd"
    )
    table.add_separator() # 添加表头下方的横向分隔线
    
    # 4. 遍历数据并添加行
    for level, cfg in DUAL_PRESETS.items():
        # 先将浮点数格式化为字符串，保留2位小数 (.2f)
        # 你的原代码逻辑：ratio_max对应MARE, ratio_mean对应MERE, ratio_rmse对应RMSE, ratio_small对应ERR_COUNT
        row_data = [
            level,
            f"{cfg['ratio_max']:.2f}",
            f"{cfg['ratio_mean']:.2f}",
            f"{cfg['ratio_rmse']:.2f}",
            f"{cfg['ratio_small']:.2f}"
        ]
        table.add_row(*row_data)
        
    # 5. 执行打印
    table.print(common.print_log)

def show_dual_tips():
    """打印双标杆精度验收标准说明"""
    separator = "=" * ConstConfig.MAX_LEN_DUAL_HELP
    divider = "-" * ConstConfig.MAX_LEN_DUAL_HELP
    
    common.print_log(separator)
    # 动态居中标题
    title = "双标杆精度验收标准"
    common.print_log(f" {title:^{ConstConfig.MAX_LEN_DUAL_HELP - 12}} ")
    common.print_log(divider)

    # 1. 标杆生成 (新增)
    common.print_log(f"{Colors.YELLOW}[标杆生成]:{Colors.RESET}")
    common.print_log(f" 双标杆模式需同时对比 {Colors.CYAN}真值{Colors.RESET} 与 {Colors.CYAN}标杆{Colors.RESET}:")
    common.print_log(f"  1. {Colors.CYAN}真值{Colors.RESET}:")
    common.print_log("     通常由 CPU/GPU 执行高精度 (FP32/FP64) 计算生成，代表数学上的'正确答案'。")
    common.print_log(f"  2. {Colors.CYAN}标杆{Colors.RESET}:")
    common.print_log("     通常指现网已商用的参考实现 (如 GPU/其他NPU 版本)，代表'预期行为'。")
    common.print_log("     判定逻辑: 待测算子的误差 不应显著大于 标杆算子的误差。")

    common.print_log(divider)

    # 2. 数值精度判定标准 (详细化)
    common.print_log(f"{Colors.YELLOW}[数值精度判定标准]:{Colors.RESET}")
    common.print_log(" 核心逻辑: 计算 (待测vs真值) 与 (标杆vs真值) 的各项误差比值。")
    
    print_metrics_formula_table()

    common.print_log(divider)

    # 3. 严格等级表
    common.print_log(f"{Colors.YELLOW}[精度严格等级 (Level) 与阈值表]:{Colors.RESET}")
    print_dual_presets_table(DUAL_PRESETS)

    common.print_log("  L0 (标准): 适用于大多数算子。")
    common.print_log("  L1 (严格): 适用于激活/Norm/反向算子。")
    common.print_log("  L2 (严苛): 适用于 FA/GMM 等高看护算子。")

    common.print_log(divider)

    # 4. Inf/NaN 判定标准 (核心逻辑更新)
    common.print_log(f"{Colors.YELLOW}[Inf/NaN 判定标准]:{Colors.RESET}")
    common.print_log(" 双标杆场景下，优先对比标杆与真值的行为：")
    common.print_log(f"  1. 若 标杆 == 真值 (同为 Inf 或 同为 NaN):")
    common.print_log(f"     -> 待测数据 必须与它们相同，才通过")
    common.print_log(f"     -> 否则不通过")
    
    common.print_log(f"  2. 若 标杆 != 真值 (溢出行为不一致):")
    common.print_log(f"     -> 待测数据 只要与其中任意一方相同，即{Colors.GREEN}通过{Colors.RESET}")

    common.print_log(f"  3. 若 三者互不相同:")
    common.print_log(f"     -> 需排查标杆与真值正确性")

    common.print_log(divider)

    # 5. 使用说明
    common.print_log(f"{Colors.YELLOW}[参数使用说明]:{Colors.RESET}")
    common.print_log(" 1. 基础命令: <ct dual 待测.npy 真值.pt 标杆.npy>")
    common.print_log(" 2. 额外参数:")
    common.print_log(f"    {'--level':<22} 指定 L0/L1/L2 标准。")
    common.print_log(f"    {'--MARE_ratio_thd':<22} 覆盖 最大相对误差 比例阈值。")
    common.print_log(f"    {'--MERE_ratio_thd':<22} 覆盖 平均相对误差 比例阈值。")
    common.print_log(f"    {'--RMSE_ratio_thd':<22} 覆盖 均方根误差 比例阈值。")
    common.print_log(f"    {'--ERR_COUNT_ratio_thd':<22} 覆盖 错误点数占比 比例阈值。")
    common.print_log(f"    {'--small_val_thd':<22} 覆盖 小值域阈值。")
    common.print_log(f"    {'--small_val_err_thd':<22} 覆盖 小值域错误阈值。")
    common.print_log(divider)

    common.print_log(f"{Colors.YELLOW}[使用示例]:{Colors.RESET}")
    common.print_log(" 场景一: <ct dual 待测数据.npy 真值.npy 标杆.npy>")
    common.print_log(" 场景二: <ct dual 待测数据.npy 真值.npy 标杆.npy --level L2 --MARE_ratio_thd 1.5>")
    common.print_log(divider)

    common.print_log(f"{Colors.YELLOW}[脚本调用示例]:{Colors.RESET}")
    common.print_log("  import sys")
    common.print_log("  import numpy as np")
    common.print_log("  from ct import dual")
    common.print_log("")
    common.print_log("  # --- 数据准备 ---")
    common.print_log("  shape = (1024, 1024)")
    common.print_log("  data_real = np.random.rand(*shape).astype(np.float32)")
    common.print_log("  # 制造微小误差 (Expect)")
    common.print_log("  data_expect = data_real + np.random.normal(0, 1e-5, shape).astype(np.float32)")
    common.print_log("  # 制造另一种误差 (Bench)")
    common.print_log("  data_bench = data_real + np.random.normal(0, 2e-5, shape).astype(np.float32)")
    common.print_log("")
    common.print_log("  # 调用 dual")
    common.print_log("  result = dual(")
    common.print_log("      test=data_real,        # 待测数据")
    common.print_log("      gt=data_expect,        # 真值数据")
    common.print_log("      bench=data_bench,      # 对照数据")
    common.print_log("      # --- 核心配置 ---")
    common.print_log("      level=\"L1\",            # 严格等级 (默认: L1)")
    common.print_log("      dtype=None,            # 数据类型 (默认: None, 自动推断)")
    common.print_log("      out_dir=\"ct/dual_result\", # 输出目录 (默认: ct/dual_result)")
    common.print_log("      save_chart=False,      # 是否保存图表 (默认: False)")
    common.print_log("      # --- 高级阈值 (Kwargs), 默认为 None ---")
    common.print_log("      MARE_ratio_thd=None,")
    common.print_log("      MERE_ratio_thd=None,")
    common.print_log("      RMSE_ratio_thd=None,")
    common.print_log("      ERR_COUNT_ratio_thd=None,")
    common.print_log("      small_val_thd=None,")
    common.print_log("      small_val_err_thd=None")
    common.print_log("  )")
    common.print_log("")
    common.print_log("  print(\"Dual Compare Report Generated.\")")
    common.print_log(separator)

# ==========================================
# 3. 验证器类 (逻辑微调)
# ==========================================

@dataclass
class MetricResult:
    max_re: float
    mean_re: float
    rmse: float
    small_err_count: int

class DualBenchmarkValidator:
    def __init__(self, config: DualBenchConfig):
        # 此时 config 已经包含了根据 dtype 选好的 small_thd
        self.cfg = config
    
    @staticmethod
    def _compute_relative_error(real: np.ndarray, expect: np.ndarray) -> np.ndarray:
        """返回相对误差的完整 Map，用于后续诊断"""
        diff = np.abs(real - expect)
        denominator = np.maximum(np.abs(expect), 1e-20)
        return diff / denominator

    @staticmethod
    def _compute_rmse(real: np.ndarray, expect: np.ndarray) -> float:
        if real.size == 0: return 0.0
        return np.sqrt(np.mean((real - expect) ** 2))

    def _partition_data(self, real: np.ndarray, golden: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        real = real.flatten()
        golden = golden.flatten()
        # 使用配置中的 small_val_thd
        mask_large = np.abs(golden) > self.cfg.small_val_thd
        return real[mask_large], golden[mask_large], real[~mask_large], golden[~mask_large]

    def _calc_single_metrics(self, real: np.ndarray, golden: np.ndarray) -> MetricResult:
        r_large, g_large, r_small, g_small = self._partition_data(real, golden)
        
        if g_large.size > 0:
            re_list = self._compute_relative_error(r_large, g_large)
            max_re = np.max(re_list)
            mean_re = np.mean(re_list)
            rmse = self._compute_rmse(r_large, g_large)
        else:
            max_re, mean_re, rmse = 0.0, 0.0, 0.0

        if g_small.size > 0:
            diff_small = np.abs(r_small - g_small)
            # 使用配置中的 small_val_err_thd
            err_count = np.sum(diff_small > self.cfg.small_val_err_thd)
        else:
            err_count = 0

        return MetricResult(float(max_re), float(mean_re), float(rmse), int(err_count))
    
    def _check_inf_nan(self, t_flat: np.ndarray, g_flat: np.ndarray, b_flat: np.ndarray) -> Dict:
        """
        执行双标杆 Inf/NaN 逻辑判定
        """
        # 1. 标记所有特殊值位置
        def is_special(arr):
            return np.isnan(arr) | np.isinf(arr)
            
        mask_interest = is_special(t_flat) | is_special(g_flat) | is_special(b_flat)
        
        if not np.any(mask_interest):
            # 必须返回统一的结构，防止 KeyError
            return {"success": True, "fail_count": 0, "fail_samples": []}

        # 2. 提取相关数据
        t_sub = t_flat[mask_interest]
        g_sub = g_flat[mask_interest]
        b_sub = b_flat[mask_interest]

        # 3. 定义匹配逻辑
        def array_match(arr1, arr2):
            return (arr1 == arr2) | (np.isnan(arr1) & np.isnan(arr2))

        # 4. 判定核心
        match_g = array_match(t_sub, g_sub)
        match_b = array_match(t_sub, b_sub)
        is_pass_mask = match_g | match_b
        
        # 5. 统计失败
        fail_sub_indices = np.where(~is_pass_mask)[0]
        fail_count = len(fail_sub_indices)
        
        fail_samples = []
        if fail_count > 0:
            # 取前10个作为样本
            sample_indices = fail_sub_indices[:10]
            # 映射回全局索引
            global_indices = np.where(mask_interest)[0]
            
            for sub_idx in sample_indices:
                g_idx = global_indices[sub_idx]
                fail_samples.append({
                    "index": int(g_idx),
                    "test": float(t_sub[sub_idx]),
                    "golden": float(g_sub[sub_idx]),
                    "bench": float(b_sub[sub_idx])
                })

        return {
            "success": fail_count == 0,
            "fail_count": fail_count,
            "fail_samples": fail_samples  # 确保键名为 fail_samples
        }

    def compare(self, test_data: np.ndarray, golden_data: np.ndarray, bench_data: np.ndarray) -> Dict:
        original_shape = test_data.shape
        t_flat = np.array(test_data, dtype=np.float64).flatten()
        g_flat = np.array(golden_data, dtype=np.float64).flatten()
        b_flat = np.array(bench_data, dtype=np.float64).flatten()

        # === 1. Inf/NaN 专项检查 ===
        inf_nan_res = self._check_inf_nan(t_flat, g_flat, b_flat)
        
        # === 2. 数值精度检查 ===
        # 使用 errstate 忽略计算 metrics 时的 Inf/NaN 警告
        # 因为我们已经有专门的 inf_nan_res 来处理它们了，这里的计算即便产生 NaN 也无所谓
        with np.errstate(invalid='ignore', divide='ignore'):
            m_test = self._calc_single_metrics(t_flat, g_flat)
            m_bench = self._calc_single_metrics(b_flat, g_flat)

        # 辅助函数
        def safe_div_ratio_fp(num, den):
            if np.isnan(den) or np.isinf(den): return 99999.0 
            return num / max(den, self.cfg.small_val_thd)
            
        def safe_div_ratio_int(num, den):
            return num / max(den, 1.0)

        ratios = {
            "max_re_ratio": safe_div_ratio_fp(m_test.max_re, m_bench.max_re),
            "mean_re_ratio": safe_div_ratio_fp(m_test.mean_re, m_bench.mean_re),
            "rmse_ratio": safe_div_ratio_fp(m_test.rmse, m_bench.rmse),
            "small_err_ratio": safe_div_ratio_int(m_test.small_err_count, m_bench.small_err_count)
        }

        checks = {
            "inf_nan": inf_nan_res["success"],
            "max_re": ratios["max_re_ratio"] <= self.cfg.ratio_max_re_thd,
            "mean_re": ratios["mean_re_ratio"] <= self.cfg.ratio_mean_re_thd,
            "rmse": ratios["rmse_ratio"] <= self.cfg.ratio_rmse_thd,
            "small_err": ratios["small_err_ratio"] <= self.cfg.ratio_small_err_count_thd
        }

        is_success = all(checks.values())

        # === 3. 诊断报告 ===
        diagnosis = None
        if not is_success:
            # 同样忽略诊断过程中的计算警告
            with np.errstate(invalid='ignore', divide='ignore'):
                diagnosis = self._diagnose_failure(test_data, golden_data, bench_data, 
                                                 t_flat, g_flat, b_flat, checks, original_shape)
            
            # 注入 Inf/NaN 诊断信息
            if not checks["inf_nan"]:
                # [关键修复] 这里使用 fail_samples，不再使用 fail_indices
                diagnosis['inf_nan_failures'] = {
                    "count": inf_nan_res["fail_count"],
                    "samples": inf_nan_res["fail_samples"] 
                }

        return {
            "success": is_success,
            "metrics_test": m_test,
            "metrics_bench": m_bench,
            "ratios": ratios,
            "checks": checks,
            "diagnosis": diagnosis
        }

    def _analyze_spatial_concentration(self, test_data: np.ndarray, golden_data: np.ndarray, 
                                     shape: tuple) -> Dict:
        """
        空间聚类分析
        """
        # [核心修改] 
        # 使用绝对误差 (Diff) 而非相对误差 (RE) 来确定错误的"物理形状"
        # 这样可以避免 Golden 接近 0 时导致的 RE 爆炸干扰空间判断
        diff_map = np.abs(test_data - golden_data)
        
        non_finite_mask = ~np.isfinite(diff_map)
        if np.any(non_finite_mask):
            diff_map[non_finite_mask] = 0.0
        max_val = np.max(diff_map)
        # 绝对误差太小，说明本身就没啥错，直接跳过
        if max_val < 1e-6: return None

        # [策略调整]
        # 设定阈值为最大绝对误差的 20%
        # 在正态分布噪声中，这能非常精准地圈出那个"矩形"
        target_thd = max_val * 0.2
        
        # 生成掩码 (后续逻辑保持不变，只是变量名从 re_map 变成了 diff_map)
        error_mask = diff_map > target_thd
        error_count = np.sum(error_mask)
        
        if error_count == 0: return None
        
        bad_indices = np.nonzero(error_mask) 
        
        dim_analysis = []
        slice_strs = []
        is_concentrated = False
        
        for dim_idx, indices in enumerate(bad_indices):
            dim_len = shape[dim_idx]
            unique_ind = np.unique(indices)
            
            # 1. 物理覆盖率 (Physical Span): 这一维上有多少个坐标涉及错误
            span_count = len(unique_ind)
            coverage = span_count / dim_len
            
            # 2. 错误汇聚量 (Error Mass): 实际有多少个错误点落在这个维度的区间内
            # indices 包含了所有错误点在该维度的坐标，直接统计即可
            total_errors_on_dim = len(indices) 
            
            # [判定逻辑] 覆盖率 < 90% 视为有聚集特征
            if coverage < 0.9: 
                min_idx = np.min(unique_ind)
                max_idx = np.max(unique_ind)
                span_len = max_idx - min_idx + 1
                
                # 统计落在这个区间内的实际错误点数量
                # (对于连续区间，通常是100%，但在有离群点时这个计算很重要)
                hits_in_range = np.sum((indices >= min_idx) & (indices <= max_idx))
                ratio_in_range = hits_in_range / error_count

                # 判定连续性 (允许20%空洞)
                if span_count >= span_len * 0.8: 
                    if min_idx == max_idx:
                        range_desc = f"单点 {min_idx}"
                    else:
                        range_desc = f"连续区间 [{min_idx}, {max_idx}]"
                    
                    # [Fix] 文案重点：展示实际汇聚的错误点数量，而非跨度
                    detail_str = (
                        f"维度 {dim_idx} (长度 {dim_len}): "
                        f"错误集中在 {range_desc}, "
                        f"汇聚了 {hits_in_range} 个异常点 (占总异常点的 {ratio_in_range:.1%})"
                    )
                    dim_analysis.append(detail_str)
                    is_concentrated = True

                else:
                    if span_count < 10:
                        range_desc = f"离散点 {list(unique_ind)}"
                        detail_str = (
                            f"维度 {dim_idx} (长度 {dim_len}): "
                            f"错误集中在 {range_desc}, "
                            f"汇聚了 {hits_in_range} 个异常点 (占总异常点的 {ratio_in_range:.1%})"
                        )
                        dim_analysis.append(detail_str)
                        is_concentrated = True
                    else:
                        # 虽然没铺满但太散了，视为全维，不单独报告聚集
                        slice_strs.append(":")
                        continue # 跳过 append detail_str
            else:
                slice_strs.append(":")
                continue

            # 只有判定为聚集时，才把 range_desc 放入切片字符串，否则放 ":"
            # 这里为了简单，如果是聚集，重新生成一遍 slice string
            if min_idx == max_idx:
                slice_strs.append(f"{min_idx}")
            else:
                slice_strs.append(f"{min_idx}:{max_idx+1}")

        cluster_slice = "[" + ", ".join(slice_strs) + "]"
        
        # 如果所有维度都是 ":", 说明没有明显聚集
        if all(s == ":" for s in slice_strs):
            is_concentrated = False

        return {
            "is_concentrated": is_concentrated,
            "cluster_slice": cluster_slice,
            "error_count": int(error_count),
            "max_re_in_cluster": float(max_val),
            "dim_details": dim_analysis
        }
    
    def _diagnose_failure(self, t_raw, g_raw, b_raw, t_flat, g_flat, b_flat, checks, shape):
        """
        核心诊断逻辑 (已修改筛选逻辑)
        筛选标准: Test_RE > (Global_Bench_Max_RE * Threshold)
        """
        report = {}
        
        # 1. 严格定义大值域掩码 (MARE 通常只关注非小值域)
        mask_large = (np.abs(g_flat) > self.cfg.small_val_thd) & np.isfinite(g_flat) & np.isfinite(b_flat)
        
        # --- MARE 分析 ---
        # 只要 MARE 检查失败，或者即便成功但您想看这种逻辑的分析，都可以进入这里
        # 这里保持原有逻辑：只有 check 失败才诊断
        if not checks['max_re']:
            if np.any(mask_large):
                # 1. 计算大值域下的相对误差列表
                t_re = self._compute_relative_error(t_flat[mask_large], g_flat[mask_large])
                b_re = self._compute_relative_error(b_flat[mask_large], g_flat[mask_large])
                
                # 2. [核心修改] 获取标杆的全局最大相对误差
                bench_max_re_global = np.max(b_re) if b_re.size > 0 else 0.0
                
                # 3. [核心修改] 计算动态限值 (Limit)
                # 逻辑: Test_RE 必须大于 (Bench_Max * Threshold) 才算异常
                threshold_val = self.cfg.ratio_max_re_thd
                if threshold_val == 0: threshold_val = 1.0 # 防除零
                
                limit_value = bench_max_re_global * threshold_val
                
                # 4. 生成筛选掩码
                fail_mask_local = t_re > limit_value
                fail_indices_local = np.where(fail_mask_local)[0]
                
                # 如果找不到点 (极罕见)，为了不让报告空着，回退到取 Test_RE 最大的点
                if len(fail_indices_local) == 0:
                    fail_indices_local = np.argsort(t_re)[-20:][::-1]
                
                # 5. 排序逻辑变更：
                # 既然是和固定 Limit 比较，我们应该按 Test_RE 的绝对大小降序排列，
                # 这样能优先看到误差最大的点，而不是 Ratio 最大的点
                bad_values = t_re[fail_indices_local]
                sorted_idx_local = np.argsort(bad_values)[::-1]
                
                # 提取 Top 20
                display_limit = 20
                top_k_indices_local = fail_indices_local[sorted_idx_local][:display_limit]
                
                # 映射回全局索引并收集数据
                global_indices_map = np.where(mask_large)[0]
                
                top_failures = []
                for loc_idx in top_k_indices_local:
                    real_flat_idx = global_indices_map[loc_idx]
                    
                    # 计算多维坐标
                    if len(shape) > 0:
                        coord = np.unravel_index(real_flat_idx, shape)
                    else:
                        coord = (real_flat_idx,)

                    # 计算点对点 Ratio 仅供参考显示 (虽然筛选逻辑变了，但在表格里看倍数还是很直观的)
                    # 避免除以0
                    current_bench_re = b_re[loc_idx]
                    ratio_val = t_re[loc_idx] / max(current_bench_re, 1e-20)

                    top_failures.append({
                        "coord": str(coord),
                        "val_golden": g_flat[mask_large][loc_idx],
                        "err_test": t_re[loc_idx],
                        "err_bench": current_bench_re, 
                        "ratio": ratio_val, # 表格中还是显示 Ratio
                        "limit_ref": limit_value # 也可以存下来备查
                    })
                
                report['mare_top_failures'] = {
                    "data": top_failures,
                    "total_fail_count": len(fail_indices_local),
                    "bench_max_re_global": bench_max_re_global, # 记录标杆最大值以便打印
                    "limit_value_used": limit_value             # 记录使用的限值
                }

            # 空间聚类分析 (保持原样)
            if len(shape) > 0:
                cluster_info = self._analyze_spatial_concentration(t_raw, g_raw, shape)
                if cluster_info:
                    report['spatial_cluster'] = cluster_info

        # --- MERE/RMSE 分析 (保持原样) ---
        if not checks['mean_re'] or not checks['rmse']:
            if np.any(mask_large):
                t_diff = np.abs(t_flat[mask_large] - g_flat[mask_large])
                b_diff = np.abs(b_flat[mask_large] - g_flat[mask_large])
                report['distribution'] = {
                    "test": np.percentile(t_diff, [50, 90, 99]),
                    "bench": np.percentile(b_diff, [50, 90, 99])
                }

        # --- Small Value 分析 (保持原样) ---
        if not checks['small_err']:
            mask_small = ~mask_large
            if np.any(mask_small):
                t_err_small = np.abs(t_flat[mask_small] - g_flat[mask_small])
                b_err_small = np.abs(b_flat[mask_small] - g_flat[mask_small])
                
                is_err_t = t_err_small > self.cfg.small_val_err_thd
                is_pass_b = b_err_small <= self.cfg.small_val_err_thd
                regressed_mask = is_err_t & is_pass_b
                
                regressed_count = np.sum(regressed_mask)
                samples = []
                if regressed_count > 0:
                    reg_indices = np.where(regressed_mask)[0][:3]
                    for idx in reg_indices:
                         samples.append({
                            "golden": g_flat[mask_small][idx],
                            "test_diff": t_err_small[idx],
                            "bench_diff": b_err_small[idx]
                        })
                report['small_val_regressed'] = {
                    "count": regressed_count,
                    "samples": samples
                }

        return report

    @staticmethod
    def plot_ratio_distribution_chart(ratio_list, baseline, title, save_path):

        if len(ratio_list) == 0: return
        bins_edges = np.arange(0, 2.01, 0.2)
        bins_labels = [f"{bins_edges[i]:.1f}~{bins_edges[i + 1]:.1f}" for i in range(len(bins_edges) - 1)]
        bins_labels.append(">2.0")
        proportions = [0] * len(bins_labels)
        for v in ratio_list:
            if v > 2.0: proportions[-1] += 1
            else: 
                idx = int(v // 0.2)
                if idx >= len(proportions) - 1: idx = len(proportions) - 2
                proportions[idx] += 1
        
        total = len(ratio_list)
        if total == 0: return
        proportions = [round(p * 100 / total, 2) for p in proportions]
        
        plt.figure(figsize=(12, 6))
        bars = plt.bar(np.arange(len(bins_labels)), proportions, edgecolor='black')
        for bar, prop in zip(bars, proportions):
            plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5, f"{prop}%", ha='center', va='bottom', fontsize=9)
        
        baseline_x = (len(bins_labels) - 0.5) if baseline > 2.0 else (int(baseline // 0.2) + 0.5)
        plt.axvline(x=baseline_x, color="red", linestyle="--", linewidth=2)
        plt.text(baseline_x, max(proportions)+5, f"Threshold: {baseline}", color="red")
        
        plt.xticks(np.arange(len(bins_labels)), bins_labels, rotation=45, ha='right')
        plt.ylabel("Proportion (%)")
        plt.title(title + " Ratio distribution")
        plt.tight_layout()
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300)
        plt.close()
        common.print_log(f"图表已保存至: {save_path}")

def print_dual_report(level, final_cfg, result, dtype_header=None, log_file="ct_dual_report.log"):
    """
    打印双标杆比较的详细报告
    :param level: 标杆级别 (L1, L2 等)
    :param final_cfg: 配置对象 (DualBenchConfig)
    :param result: validator.compare 返回的字典结果
    :param dtype_header: (新增) 数据类型描述字符串，例如 "float32 (Standard Precision)"
    """
    logger = DualLogger(log_file)
    
    # --- 1. 打印配置信息 (Header) ---
    separator = "=" * ConstConfig.MAX_LEN_DUAL_REPORT
    divider = "-" * ConstConfig.MAX_LEN_DUAL_REPORT

    common.print_log(separator)
    # 整合了 Level 和 Dtype 信息
    d_info = dtype_header if dtype_header else "Auto/Unknown"
    # 使用 Colors 替代 \033[96m
    common.print_log(f"双标杆等级: {Colors.CYAN}{level}{Colors.RESET}   数据类型: {Colors.CYAN}{d_info}{Colors.RESET}")
    common.print_log(divider)
    common.print_log(f"{Colors.YELLOW}[配置信息]:{Colors.RESET}")
    # 仅打印剩余的"比例"类阈值
    common.print_log(f"  最大相对误差比例阈值:   \t{final_cfg.ratio_max_re_thd}")
    common.print_log(f"  平均相对误差比例阈值:   \t{final_cfg.ratio_mean_re_thd}")
    common.print_log(f"  均方根误差比例阈值:     \t{final_cfg.ratio_rmse_thd}")
    common.print_log(f"  小值域错误计数比例阈值: \t{final_cfg.ratio_small_err_count_thd}")
    common.print_log(f"  小值域阈值:            \t{final_cfg.small_val_thd}")
    common.print_log(f"  小值域错误阈值:        \t{final_cfg.small_val_err_thd}")

    common.print_log(divider)
    common.print_log(f"{Colors.YELLOW}[对比结果]:{Colors.RESET}")
    common.print_log(divider)
    # --- 新增: 优先打印 Inf/NaN 检查结果 ---
    inf_nan_ok = result['checks'].get('inf_nan', True)
    inf_status = f"{Colors.GREEN}PASS{Colors.RESET}" if inf_nan_ok else f"{Colors.RED}FAIL{Colors.RESET}"
    common.print_log(f" 1. Inf/NaN 特殊值一致性检查: \t[{inf_status}]")
    if not inf_nan_ok:
        common.print_log(f"    {Colors.RED}* 警告: 检测到待测算子的 Inf/NaN 行为与真值/标杆均不一致！{Colors.RESET}")
    
    common.print_log(f" 2. 数值精度指标详细对比:")
    common.print_log(divider)

    # --- 3. 打印详细指标表格 ---
    common.print_log(f"| {'指标类别':<11} | {'待测数据':<8} | {'标杆数据':<8} | {'比值':<8} | {'阈值':<4} | {'结果':<4} |")
    common.print_log(divider)

    metrics_map = [
        ("MARE_ratio", "max_re", final_cfg.ratio_max_re_thd),
        ("MERE_ratio", "mean_re", final_cfg.ratio_mean_re_thd),
        ("RMSE_ratio", "rmse", final_cfg.ratio_rmse_thd),
        ("ERR_COUNT_ratio", "small_err_count", final_cfg.ratio_small_err_count_thd),
    ]

    for label, key, thd_val in metrics_map:
        # 从 result 对象中获取测试数据和标杆数据的指标值
        t_val = getattr(result['metrics_test'], key)
        b_val = getattr(result['metrics_bench'], key)
        
        # 映射 key 到 result['ratios'] 中的键名
        ratio_key = ""
        if key == "max_re": ratio_key = "max_re_ratio"
        elif key == "mean_re": ratio_key = "mean_re_ratio"
        elif key == "rmse": ratio_key = "rmse_ratio"
        elif key == "small_err_count": ratio_key = "small_err_ratio"
        
        ratio_val = result['ratios'][ratio_key]
        
        # 判断单项状态
        status = "OK" if ratio_val <= thd_val else "FAIL"
        # 使用 Colors.GREEN/RED 替代硬编码颜色
        color_status = f"{Colors.GREEN}{status}{Colors.RESET}" if status == "OK" else f"{Colors.RED}{status}{Colors.RESET}"
        
        # 格式化数值 (计数用整数，其他用浮点)
        val_fmt = ".6f" if "count" not in key else "d"
        
        common.print_log(f"| {label:<15} | {t_val:<12{val_fmt}} | {b_val:<12{val_fmt}} | {ratio_val:<10.4f} | {thd_val:<6.2f} | {color_status:<15} |")

    d_info = dtype_header if dtype_header else "Auto/Unknown"
    common.print_log(divider)

    # === 新增：失败诊断报告部分 ===
    diagnosis = result.get('diagnosis')
    if diagnosis:
        logger.log(f"{Colors.RED}[FAIL 分析与诊断]:{Colors.RESET}")
        # --- 新增: Inf/NaN 诊断信息 ---
        if 'inf_nan_failures' in diagnosis:
            inf_fail = diagnosis['inf_nan_failures']
            logger.log(f"{Colors.YELLOW}>> Inf/NaN 一致性异常:{Colors.RESET}")
            logger.log(f"  发现 {inf_fail['count']} 个点的特殊值行为不符合双标杆逻辑。")
            logger.log(f"  规则: Test 必须匹配 Golden 或 Bench 中的任意一个 (当涉及 Inf/NaN 时)。")
            logger.log(f"  {'-'*65}")
            logger.log(f"  {'Index':<10} | {'Golden':<15} | {'Bench':<15} | {'Test (Error)':<15}")
            logger.log(f"  {'-'*65}")
            
            # [关键修复] 遍历 samples 列表
            for s in inf_fail['samples']:
                # 简单格式化 float 为字符串，处理 nan/inf 显示
                g_str = f"{s['golden']:.4e}"
                b_str = f"{s['bench']:.4e}"
                t_str = f"{s['test']:.4e}"
                logger.log(f"  {s['index']:<10} | {g_str:<15} | {b_str:<15} | {t_str:<15}")
            
            logger.log(f"  {'-'*65}")

        # 1. MARE 分析
        if 'mare_top_failures' in diagnosis:
            # --- 新增: 打印新的筛选逻辑说明 ---
            logger.log(f"{Colors.YELLOW}>> MARE 异常分析:{Colors.RESET}")
            mf = diagnosis['mare_top_failures']
            if 'limit_value_used' in mf:
                bench_max = mf['bench_max_re_global']
                limit_val = mf['limit_value_used']
                logger.log(f"  [筛选逻辑]: Test_RE > (Bench_Max_RE * Threshold)")
                logger.log(f"   - 标杆全局最大RE: {bench_max:.2e}")
                logger.log(f"   - 允许误差限值 : {limit_val:.2e} (即 {bench_max:.2e} * Thd)")
            
            # --- 空间聚类展示 (中文优化版) ---
            if 'spatial_cluster' in diagnosis:
                sc = diagnosis['spatial_cluster']
                if sc['is_concentrated']:
                    logger.log(f"  {Colors.RED}[!!! 高风险聚集发现 !!!]{Colors.RESET}")
                    logger.log(f"  最大误差 ({sc['max_re_in_cluster']:.2e}) 并非随机分布，而是高度聚集在以下区域：")
                    logger.log(f"  复现切片 (Python Slice): {Colors.CYAN}{sc['cluster_slice']}{Colors.RESET}")
                    
                    logger.log(f"  维度细节分析:")
                    for detail in sc['dim_details']:
                        logger.log(f"   * {detail}")
                    logger.log(f"  (注: 未列出的维度表示该维度上所有数据均有涉及)")
                else:
                    logger.log(f"  [分布特征]: 误差在全图范围内随机分布 (Global)，无明显维度聚集。")
                logger.log(f"  {'-'*65}")

            # --- Top Failures 展示 ---
            data_list = mf['data']
            logger.log(f"  检测到 {mf['total_fail_count']} 个点超过允许限值。")
            logger.log(f"  按 Test_RE (待测误差) 降序排列 (Top {len(data_list)}):")
            
            # 这里的 Bench_RE 指的是该点的 Bench RE，Ratio 也是该点的 Ratio
            header = f"  {'位置':<14} | {'Golden':<10} | {'Test_RE':<10} | {'Bench_RE':<10} | {'Limit':<10}"
            logger.log(header)
            logger.log(f"  {'-'*len(header)}")

            for item in data_list:
                pos_str = item['coord']
                if len(pos_str) > 23: pos_str = pos_str[:20] + "..."
                # 这里我把最后一列改为了 Limit 参考，或者您可以根据需要打印 Ratio
                # 既然逻辑是 Limit，打印 Limit 可能更直观，表示该点是否超标
                limit_ref = item.get('limit_ref', 0.0)
                logger.log(f"  {pos_str:<16} | {item['val_golden']:<10.2e} | {item['err_test']:<10.2e} | {item['err_bench']:<10.2e} | {limit_ref:<10.2e}")

        # 2. MERE/RMSE 分析
        if 'distribution' in diagnosis:
            logger.log(f"{Colors.YELLOW}>> MERE/RMSE (分布) 异常分析:{Colors.RESET}")
            d = diagnosis['distribution']
            p50_r = d['test'][0] / max(d['bench'][0], 1e-9)
            p99_r = d['test'][2] / max(d['bench'][2], 1e-9)
            
            logger.log("  绝对误差分位数对比 (用于判断是整体偏移还是离群点):")
            # 详细解释
            logger.log(f"  {'P50 (中位数误差)':<15} | {d['test'][0]:<12.2e} | {d['bench'][0]:<12.2e} | Ratio={p50_r:.1f} (反映整体算法精度/偏移)")
            logger.log(f"  {'P99 (99%分位误差)':<15} | {d['test'][2]:<12.2e} | {d['bench'][2]:<12.2e} | Ratio={p99_r:.1f} (反映极端离群噪点)")

        # 3. Small Value 分析
        if 'small_val_regressed' in diagnosis:
            sv = diagnosis['small_val_regressed']
            logger.log(f"\n {Colors.YELLOW}>> Small Value (小值域) 异常分析:{Colors.RESET}")
            logger.log(f"  发现 {sv['count']} 个点发生了**精度退化** (即：真值很小，标杆误差达标，但待测误差超标)。")
            if sv['samples']:
                logger.log("  典型退化样本:")
                for s in sv['samples']:
                    logger.log(f"   Golden: {s['golden']:.2e} -> Test_Diff: {s['test_diff']:.2e} (Bench_Diff: {s['bench_diff']:.2e})")
            
    logger.log(separator)