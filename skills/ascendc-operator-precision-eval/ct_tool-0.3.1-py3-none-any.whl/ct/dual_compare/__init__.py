from .dual_benchmark import (
    DualBenchmarkValidator, 
    MetricResult,
    print_dual_report,
    resolve_dual_config,
    show_dual_tips
)

__all__ = [
    "DualBenchmarkValidator", 
    "MetricResult",
    "print_dual_report",
    "resolve_dual_config",
    "show_dual_tips"
]

from .analyze import process_excel_and_check