import pandas as pd
import numpy as np
import ast
from scipy import stats
import os
import matplotlib.pyplot as plt
import seaborn as sns
import re

# 设置绘图风格
sns.set_theme(style="whitegrid")
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False    # 用来正常显示负号

# ==========================================
# 1. 核心统计分析函数 (已修改)
# ==========================================

def analyze_metric_consistency(clean_data, metric_name):
    """
    对一组已清洗的比值数据进行统计一致性分析。
    修改点：返回 boot_medians 用于绘图
    """
    n = len(clean_data)

    # --- 样本量硬性卡口 ---
    if n < 20:
        return {
            "metric": metric_name,
            "status": "FAIL",
            "n": n,
            "median": 0 if n == 0 else np.median(clean_data),
            "ci": (0, 0),
            "p_value": 0,
            "boot_medians": [], # 空列表
            "reason": f"样本数不足 (当前: {n}, 要求: >=20)"
        }

    data_arr = np.array(clean_data)

    # 1. 描述性统计 (观测值)
    median = np.median(data_arr)

    # 2. 统计检验 (Wilcoxon - 仅作参考)
    try:
        log_data = np.log(data_arr + 1e-9) 
        w_stat, p_value = stats.wilcoxon(log_data, alternative='two-sided')
    except ValueError:
        p_value = 1.0 

    # 3. Bootstrap 置信区间 (95%)
    rng = np.random.default_rng(seed=42)
    boot_medians = []
    
    for _ in range(2000):
        # resample: 有放回地抽取与原数组相同大小的样本
        sample = rng.choice(data_arr, size=n, replace=True)
        boot_medians.append(np.median(sample))

    ci_lower = np.percentile(boot_medians, 2.5)
    ci_upper = np.percentile(boot_medians, 97.5)

    # 4. 判定逻辑
    status = "PASS"
    fail_reason = ""
    THRESHOLD = 1.0

    # 宽松的指标: 仅当 CI 下限 > 1.0 时判为 FAIL
    if ci_lower > THRESHOLD:
        status = "FAIL"
        fail_reason = f"统计显著劣于标杆 (CI下限 {ci_lower:.4f} > {THRESHOLD})"

    return {
        "metric": metric_name,
        "status": status,
        "n": n,
        "median": median,
        "ci": (ci_lower, ci_upper),
        "boot_medians": boot_medians, # 新增返回
        "p_value": p_value,
        "reason": fail_reason
    }


# ==========================================
# 2. 可视化绘图函数 (新增)
# ==========================================

def visualize_consistency(raw_data, boot_medians, result_info, save_dir, case_title):
    """
    绘制上下两张图：
    1. 上图：原始数据分布 (Histogram + KDE)
    2. 下图：Bootstrap 中位数分布 (Histogram + 95% CI区域)
    """
    metric_name = result_info['metric']
    status = result_info['status']
    ci_lower, ci_upper = result_info['ci']
    observed_median = result_info['median']
    
    # 创建画布
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10), constrained_layout=True)
    
    # 标题颜色：FAIL为红，PASS为绿
    title_color = 'red' if status == 'FAIL' else 'darkgreen'
    status_text = f"[{status}]"
    
    # ---------------------------
    # 上图：原始数据分布
    # ---------------------------
    sns.histplot(raw_data, kde=True, ax=ax1, color='skyblue', stat='density')
    # 绘制观测中位数线
    ax1.axvline(observed_median, color='blue', linestyle='--', linewidth=2, label=f'Observed Median: {observed_median:.4f}')
    # 绘制标杆线 (1.0)
    ax1.axvline(1.0, color='gray', linestyle='-', linewidth=1, alpha=0.5, label='Baseline (1.0)')
    
    ax1.set_title(f"原始数据分布 (N={len(raw_data)}) - {metric_name}", fontsize=12)
    ax1.set_xlabel("Ratio Value")
    ax1.legend()

    # ---------------------------
    # 下图：Bootstrap 中位数分布 (95% CI)
    # ---------------------------
    if len(boot_medians) > 0:
        sns.histplot(boot_medians, kde=True, ax=ax2, color='orange', stat='density')
        
        # 绘制 CI 区域
        # 获取Y轴范围以绘制填充色块
        y_min, y_max = ax2.get_ylim()
        ax2.fill_betweenx([y_min, y_max], ci_lower, ci_upper, color='orange', alpha=0.2, label='95% CI Range')
        
        # 绘制 CI 边界线
        ax2.axvline(ci_lower, color='red', linestyle=':', linewidth=2, label=f'CI Lower: {ci_lower:.4f}')
        ax2.axvline(ci_upper, color='red', linestyle=':', linewidth=2, label=f'CI Upper: {ci_upper:.4f}')
        
        # 绘制判定阈值线
        ax2.axvline(1.0, color='black', linestyle='-', linewidth=2, label='Threshold (1.0)')
        
        ax2.set_title(f"Bootstrap 中位数分布 (95% CI) - {status_text}", fontsize=12, color=title_color, fontweight='bold')
        ax2.set_xlabel("Median Value")
        ax2.legend(loc='upper right')
    else:
        ax2.text(0.5, 0.5, "样本不足，无法进行 Bootstrap 分析", ha='center', va='center')

    # ---------------------------
    # 保存图片
    # ---------------------------
    # 清洗文件名，去除非法字符
    safe_case = re.sub(r'[\\/*?:"<>|]', "_", case_title)
    safe_metric = re.sub(r'[\\/*?:"<>|]', "_", metric_name)
    
    filename = f"{status}_{safe_case}_{safe_metric}.png"
    # 限制文件名长度防止报错
    if len(filename) > 200:
        filename = filename[:200] + ".png"
        
    save_path = os.path.join(save_dir, filename)
    plt.savefig(save_path, dpi=100)
    plt.close(fig) # 关闭画布释放内存


# ==========================================
# 3. 数据解析辅助函数 (保持不变)
# ==========================================

def parse_indicators(filename, source_id, excel_row_idx, indicators, target_storage):
    """
    解析单个文件的指标字典，存入 (value, source_id, row_idx) 三元组
    """
    target_suffixes = ['最大相对误差比例', '平均相对误差比例', '均方根误差比例']

    has_real = any('[real]' in k for k in indicators.keys())
    has_imag = any('[imag]' in k for k in indicators.keys())

    def store_metric(sub_name, metric_key, val):
        full_output_name = f"{filename} {sub_name}".strip()
        if full_output_name not in target_storage:
            target_storage[full_output_name] = {}
        
        clean_metric_name = metric_key
        if ']' in metric_key:
            clean_metric_name = metric_key.split(']')[-1]
            
        if clean_metric_name not in target_storage[full_output_name]:
            target_storage[full_output_name][clean_metric_name] = []
        
        target_storage[full_output_name][clean_metric_name].append((val, source_id, excel_row_idx))

    if has_real or has_imag:
        for key, value in indicators.items():
            for suffix in target_suffixes:
                if key.endswith(suffix):
                    if key.startswith('[real]'):
                        store_metric("[Real]", suffix, value)
                    elif key.startswith('[imag]'):
                        store_metric("[Imag]", suffix, value)
    else:
        for key, value in indicators.items():
            for suffix in target_suffixes:
                if key.endswith(suffix):
                    store_metric("", suffix, value)


# ==========================================
# 4. 主逻辑函数 (已修改)
# ==========================================

def process_excel_and_check(file_path):
    """
    读取 Excel 并执行一致性检查。
    :param file_path: Excel 文件路径
    :return: int (failed_cases 数量)
    """
    print(f"正在读取文件: {file_path} ...")
    
    if not os.path.exists(file_path):
        print(f"错误: 找不到文件 {file_path}")
        return -1

    try:
        df = pd.read_excel(file_path)
    except Exception as e:
        print(f"读取 Excel 失败: {e}")
        return -1

    # 创建图片保存目录
    plot_dir = "analysis_plots"
    if not os.path.exists(plot_dir):
        os.makedirs(plot_dir)
        print(f"创建图片输出目录: {plot_dir}")
    else:
        print(f"图片将保存至: {plot_dir}")

    # 结构: { key: { output: { metric: [(val, source, row_idx), ...] } } }
    cases_data = {}

    print("正在解析数据...\n")

    for index, row in df.iterrows():
        try:
            current_excel_row = index + 2
            if len(row) < 21: continue 

            col_b = row['输入shape']
            col_c = row['输入dtype']
            col_v_str = row['精度详情']

            if pd.isna(col_b) or pd.isna(col_c) or pd.isna(col_v_str):
                continue

            unique_key = (str(col_b), str(col_c))
            if unique_key not in cases_data:
                cases_data[unique_key] = {}

            try:
                record_dict = ast.literal_eval(col_v_str)
            except:
                continue
            
            if isinstance(record_dict, dict):
                for gpu_ip, results_list in record_dict.items():
                    if not isinstance(results_list, list): continue
                    
                    for item in results_list:
                        raw_filename = item.get('filename', 'unknown')
                        base_filename = raw_filename.replace('.pt', '')
                        indicators = item.get('new_benchmark_indicate', {})
                        
                        if not indicators:
                            continue
                        
                        current_source_id = f"{gpu_ip}::{raw_filename}"
                        parse_indicators(base_filename, current_source_id, current_excel_row, indicators, cases_data[unique_key])
        except Exception as e:
            continue

    # ==========================================
    # 统计分析与全量报告输出
    # ==========================================

    print(f"{'='*100}")
    print(f"{'精度一致性统计报告 (Threshold: CI_Lower > 1.0 => FAIL)':^100}")
    print(f"{'='*100}")

    total_cases = 0
    failed_cases = 0

    for (case_name, case_sub), output_groups in cases_data.items():
        total_cases += 1
        case_has_failure = False
        report_lines = []
        
        sorted_outputs = sorted(output_groups.keys())

        for out_name in sorted_outputs:
            metrics_dict = output_groups[out_name]
            sorted_metrics = sorted(metrics_dict.keys())
            
            for metric_name in sorted_metrics:
                raw_data_tuples = metrics_dict[metric_name]
                
                # 数据解包
                clean_values = []
                clean_sources = []
                clean_rows = []
                
                for val, src, row_idx in raw_data_tuples:
                    if val is not None and not np.isnan(val):
                        clean_values.append(val)
                        clean_sources.append(src)
                        clean_rows.append(row_idx)
                
                # ---> 核心统计 <---
                res = analyze_metric_consistency(clean_values, metric_name)
                
                # ---> 核心绘图 (新增) <---
                # 只有当样本数足够进行统计时才绘图
                if res['n'] >= 20:
                    # 组合一个用于文件名的 Case 标识
                    plot_case_title = f"{case_name}_{case_sub}_{out_name}"
                    visualize_consistency(clean_values, res['boot_medians'], res, plot_dir, plot_case_title)

                status_icon = "✅" if res['status'] == 'PASS' else "❌"
                if res['status'] == 'FAIL':
                    case_has_failure = True
                
                line = (
                    f"   {status_icon} [{out_name:<20}] {metric_name:<10} | "
                    f"N={res['n']:<3} | Median={res['median']:.4f} | "
                    f"95% CI=[{res['ci'][0]:.4f}, {res['ci'][1]:.4f}]"
                )
                
                if res['status'] == 'FAIL':
                    line += f" | ⚠️ {res['reason']}"
                
                report_lines.append(line)

                # =================================================
                # 失败用例诊断
                # =================================================
                if res['status'] == 'FAIL' and len(clean_values) > 0:
                    val_arr = np.array(clean_values)
                    src_arr = np.array(clean_sources)
                    row_arr = np.array(clean_rows)
                    
                    top_k = 3
                    bad_indices = np.argsort(val_arr)[-top_k:][::-1]
                    
                    diagnostic_info = "      ☢ 罪魁祸首 (Top Worst Samples):\n"
                    for idx in bad_indices:
                        if '::' in src_arr[idx]:
                            _, s_file = src_arr[idx].split('::')
                        else:
                            s_file = src_arr[idx]
                        
                        r_num = row_arr[idx]
                        diagnostic_info += (
                            f"         - Excel行号: {r_num:<5} | Ratio: {val_arr[idx]:.4f} | "
                            f"File: {s_file}\n"
                        )
                    
                    report_lines.append(diagnostic_info)

        # 打印 Case 结果
        title_icon = "🔴" if case_has_failure else "🟢"
        print(f"\n{title_icon} 用例: [{case_name}] - [{case_sub}]")
        print(f"   (检测到输出数量: {len(sorted_outputs)})")
        
        for line in report_lines:
            print(line)
            
        if case_has_failure:
            failed_cases += 1

    print("\n" + "="*100)
    print(f"检查完成。总用例: {total_cases}, 失败: {failed_cases}, 通过: {total_cases - failed_cases}")
    print(f"统计图表已保存至: {os.path.abspath(plot_dir)}")
    print("="*100)
    
    return failed_cases
