import os
import sys
from datetime import datetime


def get_html_template():
    """返回HTML模板内容"""
    return '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>【算子设计】{project_name} - V6.0 完整版</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js "></script>
    <style>
        :root {{ 
            --primary-color: #2c3e50; 
            --accent-color: #3498db; 
            --sidebar-width: 260px;
            --rightbar-width: 380px;
            --header-height: 60px;
        }}
        
        * {{ box-sizing: border-box; }}
        body {{ 
            font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif; 
            margin: 0; padding: 0; 
            background-color: #f4f6f9; 
            height: 100vh; 
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }}

        /* Top Header */
        header {{
            height: var(--header-height);
            background: #333;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            z-index: 1000;
            flex-shrink: 0;
        }}
        .btn-group button, .btn-group label {{
            background: #555; border: 1px solid #777; color: white;
            padding: 5px 12px; margin-left: 8px; cursor: pointer;
            border-radius: 4px; font-size: 13px;
        }}
        .btn-group button:hover {{ background: var(--accent-color); }}

        /* Layout Container */
        .container {{
            display: flex;
            flex: 1;
            height: calc(100vh - var(--header-height));
            overflow: hidden;
        }}

        /* Left Sidebar */
        .sidebar-left {{
            width: var(--sidebar-width);
            background: white;
            border-right: 1px solid #ddd;
            overflow-y: auto;
            padding: 20px;
            flex-shrink: 0;
        }}
        .nav-item {{
            display: block;
            padding: 8px 10px;
            color: #555;
            text-decoration: none;
            border-radius: 4px;
            margin-bottom: 2px;
            font-size: 14px;
            cursor: pointer;
        }}
        .nav-item:hover {{ background: #eef7fe; color: var(--accent-color); }}
        .nav-h1 {{ font-weight: bold; margin-top: 10px; }}
        .nav-h2 {{ padding-left: 25px; font-size: 13px; }}
        .nav-h3 {{ padding-left: 40px; font-size: 12px; }}

        /* Main Content */
        .main-content {{
            flex: 1;
            padding: 40px;
            overflow-y: auto;
            background: white;
            max-width: 1000px;
            margin: 0 auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }}

        /* Right Sidebar */
        .sidebar-right {{
            width: var(--rightbar-width);
            background: #fdfdfd;
            border-left: 1px solid #ddd;
            padding: 0;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            transition: width 0.3s;
        }}
        .sidebar-header {{
            padding: 10px 15px;
            background: #eee;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
        }}
        .sidebar-body {{
            padding: 15px;
            overflow-y: auto;
            flex: 1;
        }}
        
        /* Mermaid Editor */
        .mermaid-editor-box {{ display: flex; flex-direction: column; gap: 10px; }}
        .mermaid-preview {{ 
            border: 1px dashed #ccc; 
            min-height: 200px; 
            background: white; 
            padding: 10px; 
            text-align: center;
        }}
        textarea.code-box {{ 
            width: 100%; height: 150px; 
            background: #222; color: #0f0; 
            font-family: monospace; font-size: 12px; 
            resize: vertical;
        }}
        .flow-controls {{
            display: flex; flex-wrap: wrap; gap: 5px; background: #eee; padding: 10px; border-radius: 4px;
        }}
        .flow-controls input, .flow-controls select {{
            padding: 4px; border: 1px solid #ccc; border-radius: 3px; font-size: 12px;
        }}

        /* Common Elements */
        h1.doc-title {{ 
            border-bottom: 2px solid var(--primary-color); 
            color: var(--primary-color); 
            margin-top: 40px;
        }}
        h1.doc-title:first-child {{ margin-top: 0; }}
        h2 {{ 
            border-bottom: 1px solid #eee; 
            margin-top: 30px; 
            color: var(--primary-color); 
        }}
        h3 {{ 
            margin-top: 20px; 
            color: #444; 
        }}
        
        .editable-area {{ 
            border: 1px dashed #ccc; 
            padding: 10px; 
            min-height: 40px; 
            background: #fafafa; 
            border-radius: 4px; 
            margin: 5px 0; 
            white-space: pre-wrap; 
        }}
        .editable-area:focus {{ 
            background: #fff; 
            border-color: var(--accent-color); 
            outline: none; 
        }}
        
        /* Guidance Box */
        .guidance-box {{ 
            background: #e3f2fd; 
            border-left: 4px solid #2196F3; 
            padding: 10px 15px; 
            font-size: 13px; 
            color: #333; 
            margin: 10px 0;
            border-radius: 0 4px 4px 0;
        }}
        .guidance-box strong {{ color: #1976D2; }}
        
        /* Warning/Requirement Box */
        .requirement-box {{ 
            background: #e3f2fd; 
            border-left: 4px solid #1976D2; 
            padding: 10px 15px; 
            font-size: 13px; 
            color: #333; 
            margin: 10px 0;
            border-radius: 0 4px 4px 0;
        }}
        .requirement-box ul, .guidance-box ul {{ margin: 5px 0; padding-left: 20px; }}
        .requirement-box li, .guidance-box li {{ margin: 3px 0; }}
        
        /* Table Styles */
        table {{ 
            width: 100%; 
            border-collapse: collapse; 
            margin: 10px 0; 
            font-size: 13px; 
            table-layout: fixed; 
        }}
        th, td {{ 
            border: 1px solid #ddd; 
            padding: 6px; 
            vertical-align: top; 
        }}
        th {{ 
            background-color: #f2f2f2; 
            text-align: center; 
        }}
        table input, table textarea, table select {{ 
            width: 100%; 
            border: 1px solid transparent; 
            background: transparent; 
            font-family: inherit; 
            font-size: inherit; 
            resize: vertical; 
        }}
        table input:focus, table textarea:focus, table select:focus {{ 
            border: 1px solid var(--accent-color); 
            background: white; 
        }}
        
        /* Color highlights */
        .color-blue {{ color: #1976D2; font-weight: bold; }}
        .color-red {{ color: #d32f2f; font-weight: bold; }}
        
        /* Example table styling */
        .example-table {{ background: #f9f9f9; }}
        .example-table th {{ background: #e0e0e0; }}

        /* Checkbox styling */
        .checklist-table input[type="checkbox"] {{
            transform: scale(1.2);
            margin: 0 auto;
            display: block;
        }}
        .checklist-table td:nth-child(1) {{
            text-align: center;
        }}

        /* Mermaid insert button */
        .mermaid-btn {{
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 3px 8px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 12px;
            margin-left: 10px;
        }}
        .mermaid-btn:hover {{
            background: #2980b9;
        }}

        /* Auto-complete suggestion */
        .auto-suggest {{
            background: #f0f8ff;
            border: 1px dashed #3498db;
            padding: 2px 5px;
            font-size: 11px;
            color: #1976D2;
            margin-left: 5px;
        }}

        /* Mermaid container for any section */
        .mermaid-container {{
            margin: 10px 0;
            padding: 10px;
            border: 1px dashed #ccc;
            background: white;
            position: relative;
        }}
        .mermaid-container .mermaid-close {{
            position: absolute;
            top: 5px;
            right: 5px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
    </style>
</head>
<body>

    <header>
        <h1>🛠️ 算子设计 {project_name} - V6.0</h1>
        <div class="btn-group">
            <label for="fileInput">📂 导入</label>
            <input type="file" id="fileInput" accept=".md" onchange="importMarkdown(this)" style="display:none">
            <button onclick="exportMarkdown()">💾 导出 Markdown</button>
            <button onclick="toggleRightSidebar()">👁️ 切换工具栏</button>
            <button onclick="insertMermaidToSelection()">📊 插入流程图</button>
        </div>
    </header>

    <div class="container">
        <nav class="sidebar-left" id="toc">
            </nav>

        <main class="main-content" id="mainScroll">
            <h1 class="doc-title" id="title_1">1. 需求分析</h1>
            
            <h2 id="title_1_1">1.1 需求背景</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此处要求粘贴AR链接与截图。</li>
                    <li><span class="color-red">②说明需求来源，以及涉及到的周边组件。明确是否要额外PTA、图模式的适配，若有则需要同步交付。</span></li>
                </ul>
            </div>
            <div class="editable-area" id="content_1_1" contenteditable="true" data-section="1_1"></div>

            <h2 id="title_1_2">1.2 功能分析</h2>
            
            <h3>- 接口功能</h3>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①功能说明应详细，指明算子的具体功能和特性。</li>
                    <li>②若为存量算子迭代，应说明具体的修改，带来的收益/影响。<br>
                        例如：基于XX场景的的功能断点补齐需求，新增MoeGatingTopKSoftmax融合算子，该算子在Moe计算中，对输入X做Softmax计算后取topK操作。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_1_2_func" contenteditable="true" data-section="1_2_func"></div>

            <h3>- 计算公式</h3>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①格式如以下的，若为反向需要则列出推导过程。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_1_2_formula" contenteditable="true" data-section="1_2_formula"></div>

            <h3>- 原型设计</h3>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此处填充输入和输出的名称、类型（输入/属性/输出）、支持Shape、数据类型、数据格式以及其具体的意义。</li>
                    <li>②若基于存量算子修改，则只补充增量变化。</li>
                </ul>
            </div>
            <table id="protoTable">
                <thead>
                    <tr>
                        <th style="width: 12%;">参数名</th>
                        <th style="width: 12%;">入参类型</th>
                        <th style="width: 10%;">默认值</th>
                        <th style="width: 10%;">基础类型</th>
                        <th style="width: 20%;">规格映射</th>
                        <th style="width: 20%;">说明/逻辑</th>
                        <th style="width: 6%;">操作</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            <button style="background:#28a745; color:white; border:none; border-radius:3px; cursor:pointer; margin-top:5px;" onclick="addRow('protoTable')">+ 添加参数</button>

            <h3>- 原型约束</h3>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此处填充输入、输出之间存在的依赖关系。</li>
                    <li>②指明输入的shape边界。</li>
                    <li>③指明输入的值域边界。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_1_2_const" contenteditable="true" data-section="1_2_const"></div>

            <h2 id="title_1_3">1.3 对标实现分析</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此项信息需SE/MDE给出。</li>
                    <li>②具体说明和竞品的异同，包括不限于关键处理、功能特性、输入输出等。</li>
                    <li>③注明竞品的确定性策略是否默认开启。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_1_3" contenteditable="true" data-section="1_3"></div>

            <h1 class="doc-title" id="title_2">2. 特性实现方案</h1>
            
            <h2 id="title_2_1">2.1 算子整体计算流程图</h2>
            <div class="guidance-box">
                <strong>提示：</strong>下图由右侧工具栏生成。如需编辑，请在右侧操作。
            </div>
            <div id="mainFlowchartDisplay" class="mermaid-preview" style="border:none; min-height:100px;"></div>
            <textarea id="hiddenMermaidCode" style="display:none;">graph TD
    Start(开始) --> Check{{校验}}
    Check --> Compute[计算]
    Compute --> End(结束)</textarea>
            <div class="editable-area" id="content_2_1" contenteditable="true" data-section="2_1"></div>

            <h2 id="title_2_2">2.2 ACLNN接口设计</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此处填充ACLNN接口的详细设计，包括接口名称、参数、返回值等。</li>
                    <li>②需要说明接口的调用方式和注意事项。</li>
                </ul>
            </div>
            <table id="opapiTable">
                <thead>
                    <tr>
                        <th style="width: 15%;">接口名称</th>
                        <th style="width: 20%;">参数列表</th>
                        <th style="width: 15%;">返回值</th>
                        <th style="width: 40%;">功能说明</th>
                        <th style="width: 10%;">操作</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            <button style="background:#28a745; color:white; border:none; border-radius:3px; cursor:pointer; margin-top:5px;" onclick="addOpapiRow('opapiTable')">+ 添加接口</button>
            <div class="editable-area" id="content_2_2" contenteditable="true" data-section="2_2"></div>

            <h2 id="title_2_3">2.3 Infershape设计</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此处主要为对输出的Dtype和Shape的推导逻辑。</li>
                    <li>②需要对-1/-2场景做特殊适配。-1 场景：unknownShape、-2场景：unknownRank。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_2_3" contenteditable="true" data-section="2_3"></div>

            <h2 id="title_2_4">2.4 Tiling设计</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①TilingKey的设计采用范式完成，并指明实际意义。</li>
                    <li>②此处完成分核策略的设计，可使用图示辅助说明。</li>
                    <li>③若在此对输入校验，应对每个输入设计上限；若无约束，应每一维度应泛化至2^31（同时保证GM不超上限）。</li>
                    <li>④注意TilingData需要内存对齐。</li>
                </ul>
            </div>
            <table id="tilingTable" class="example-table">
                <thead>
                    <tr>
                        <th style="width: 20%;">变量名</th>
                        <th style="width: 40%;">语义</th>
                        <th style="width: 40%;">设计边界</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" placeholder="例如: groupNum"></td>
                        <td><input type="text" placeholder="例如: 分组数量"></td>
                        <td><input type="text" placeholder="例如: [1, 65536], 需内存对齐"></td>
                    </tr>
                </tbody>
            </table>
            <button style="background:#28a745; color:white; border:none; border-radius:3px; cursor:pointer; margin-top:5px;" onclick="addTilingRow('tilingTable')">+ 添加变量</button>
            <div class="guidance-box">
                <strong>示例参考：</strong><br>
                以下为GMMBaseParams中的部分变量示例：<br>
                • groupNum: 分组数量, 边界[1, 65536]<br>
                • coreNum: 核心数量, 边界[1, 32]<br>
                • ubBaseK: UB中K维度的基础大小, 边界[32, 16384]<br>
                • workspaceSize: 工作空间大小, 边界[0, 2^64-1]<br>
                详细参考见代码中的TILING_DATA_DEF定义。
            </div>
            <div class="editable-area" id="content_2_4" contenteditable="true" data-section="2_4"></div>

            <h2 id="title_2_5">2.5 片上内存资源设计</h2>
            <div class="guidance-box">
                <strong>填写要求：</strong>
                <ul>
                    <li>①详细列出UB空间的具体使用分配。</li>
                    <li>②若涉及L1，需要给出具体的资源分配。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_2_5" contenteditable="true" data-section="2_5"></div>

            <h2 id="title_2_6">2.6 Kernel方案</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①用图示说明算子的计算流程，若存在多个分支，每个分支需要做详细说明。</li>
                    <li>②注明算子的精度转换策略，要和竞品对齐，若未对齐说明理由。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_2_6" contenteditable="true" data-section="2_6"></div>

            <h1 class="doc-title" id="title_3">3. 其他算子交付件</h1>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①其他算子交付件包括README.md，Examples，ACLNN文档、UT和DT。</li>
                    <li>②各项交付件的要求和功能如下：
                        <ul>
                            <li><strong>README.md</strong>：算子说明文档。包括支持硬件、功能和参数信息。</li>
                            <li><strong>Example</strong>：算子调用示例。为Aclnn接口的C++调用示例，代码上库时需要保证此示例可以正常调用。</li>
                            <li><strong>ACLNN文档</strong>：ACLNN接口说明文档，包括对ACLNN的接口功能、输入输出及其约束等说明。</li>
                            <li><strong>UT</strong>：<strong>单元测试，必须具备</strong>。包括对infershape、tiling和Kernel的功能及覆盖率测试。</li>
                            <li><strong>DT</strong>：ATK工具的测试看护，能够实现对算子功能、精度和性能的看护，<strong>至少需要200条基础用例</strong>，随功能一起交付。</li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="editable-area" id="content_3" contenteditable="true" data-section="3"></div>

            <h2 id="title_3_1">3.1 交付件Checklist</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①请勾选已完成的交付件，并填写相关备注信息。</li>
                    <li>②新增交付件可在表格中自行添加。</li>
                </ul>
            </div>
            <table id="checklistTable" class="checklist-table">
                <thead>
                    <tr>
                        <th style="width: 8%;">✓</th>
                        <th style="width: 25%;">交付件名称</th>
                        <th style="width: 20%;">负责人</th>
                        <th style="width: 15%;">完成状态</th>
                        <th style="width: 32%;">备注</th>
                        <th style="width: 10%;">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="checkbox" checked></td>
                        <td><input type="text" value="README.md" placeholder="交付件名称"></td>
                        <td><input type="text" placeholder="负责人"></td>
                        <td>
                            <select>
                                <option value="已完成">已完成</option>
                                <option value="进行中">进行中</option>
                                <option value="未开始">未开始</option>
                            </select>
                        </td>
                        <td><input type="text" placeholder="备注信息"></td>
                        <td><button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><input type="text" value="Example" placeholder="交付件名称"></td>
                        <td><input type="text" placeholder="负责人"></td>
                        <td>
                            <select>
                                <option value="已完成">已完成</option>
                                <option value="进行中" selected>进行中</option>
                                <option value="未开始">未开始</option>
                            </select>
                        </td>
                        <td><input type="text" placeholder="备注信息"></td>
                        <td><button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><input type="text" value="ACLNN文档" placeholder="交付件名称"></td>
                        <td><input type="text" placeholder="负责人"></td>
                        <td>
                            <select>
                                <option value="已完成">已完成</option>
                                <option value="进行中">进行中</option>
                                <option value="未开始" selected>未开始</option>
                            </select>
                        </td>
                        <td><input type="text" placeholder="备注信息"></td>
                        <td><button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><input type="text" value="UT" placeholder="交付件名称"></td>
                        <td><input type="text" placeholder="负责人"></td>
                        <td>
                            <select>
                                <option value="已完成">已完成</option>
                                <option value="进行中">进行中</option>
                                <option value="未开始" selected>未开始</option>
                            </select>
                        </td>
                        <td><input type="text" placeholder="备注信息"></td>
                        <td><button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button></td>
                    </tr>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><input type="text" value="DT" placeholder="交付件名称"></td>
                        <td><input type="text" placeholder="负责人"></td>
                        <td>
                            <select>
                                <option value="已完成">已完成</option>
                                <option value="进行中">进行中</option>
                                <option value="未开始" selected>未开始</option>
                            </select>
                        </td>
                        <td><input type="text" placeholder="备注信息"></td>
                        <td><button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button></td>
                    </tr>
                </tbody>
            </table>
            <button style="background:#28a745; color:white; border:none; border-radius:3px; cursor:pointer; margin-top:5px;" onclick="addChecklistRow('checklistTable')">+ 添加交付件</button>
            <div class="editable-area" id="content_3_1" contenteditable="true" data-section="3_1"></div>

            <h1 class="doc-title" id="title_4">4. 测试设计（开发&&测试）</h1>
            
            <h2 id="title_4_1">4.1 测试标杆</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①此处填充实现精度对比的测试标杆脚本。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_4_1" contenteditable="true" data-section="4_1"></div>

            <h2 id="title_4_2">4.2 测试用例设计</h2>
            <div class="requirement-box">
                <strong><span class="color-blue">设计要求：</span></strong>
                <ul>
                    <li>①覆盖支持规格、模型场景基础功能、边界值、约束内场景，要求精度符合新精度标准，性能达到目标。</li>
                    <li>②自测用例的设计和方法标准参考<a href="https://wiki.huawei.com/domains/68949/wiki/106372/WIKI202408094263045 ">算子开发自验证质量标准</a>。</li>
                    <li>②类似Rsqrt、sqrt、div、Reciprocal等存在入参值域限制的操作，补充特殊值用例。</li>
                </ul>
            </div>

            <h3 id="title_4_2_1">4.2.1 白盒用例</h3>
            <div class="guidance-box">
                <strong>填写要求：</strong>
                <ul>
                    <li>①边界自验证，覆盖输入的shape和value边界约束。</li>
                    <li>②异常场景的自验证，覆盖算子资料中的约束。</li>
                    <li>③内存检测的自验证，覆盖非对齐场景OOM内存检测。</li>
                    <li>④使用下表进行整体说明。</li>
                    <li>⑤在"验证场景"列输入参数时，验证用例列会自动补全格式。</li>
                </ul>
            </div>
            <table id="whiteBoxTable" class="example-table">
                <thead>
                    <tr>
                        <th style="width: 20%;">验证场景</th>
                        <th style="width: 50%;">验证用例</th>
                        <th style="width: 30%;">备注</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" placeholder="边界验证" onblur="autoCompleteTestCase(this, this.value)"></td>
                        <td><input type="text" placeholder="验证用例"></td>
                        <td><input type="text" placeholder="备注"></td>
                    </tr>
                </tbody>
            </table>
            <button style="background:#28a745; color:white; border:none; border-radius:3px; cursor:pointer; margin-top:5px;" onclick="addWhiteBoxRow('whiteBoxTable')">+ 添加用例</button>

            <h3 id="title_4_2_2">4.2.2 性能用例</h3>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>①性能测试需要指明对比的性能来源和标准。<br>
                        例如：XX场景下和小算子拼接对比提升10%，XX分支模式和XXV1版本提升20%。</li>
                    <li>②使用下表格式进行整体说明。</li>
                </ul>
            </div>
            <table id="perfTable" class="example-table">
                <thead>
                    <tr>
                        <th style="width: 60%;">验证项</th>
                        <th style="width: 15%;">用例数</th>
                        <th style="width: 25%;">备注</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" placeholder="模型场景，小算子拼接性能提升10%"></td>
                        <td><input type="text" placeholder="100"></td>
                        <td><input type="text" placeholder=""></td>
                    </tr>
                </tbody>
            </table>
            <button style="background:#28a745; color:white; border:none; border-radius:3px; cursor:pointer; margin-top:5px;" onclick="addSimpleRow('perfTable')">+ 添加用例</button>

            <h1 class="doc-title" id="title_5">5. 遗留问题</h1>
            <div class="requirement-box">
                <strong><span class="color-blue">填写要求：</span></strong>
                <ul>
                    <li>该部分填写算子功能边界、精度相关、性能相关和标杆相关等重点注意项、未达成事项，便于测试边界覆盖及后续迭代开发。</li>
                </ul>
            </div>
            <div class="editable-area" id="content_5" contenteditable="true" data-section="5"></div>
            
            <div style="height: 200px;"></div>
        </main>

        <aside class="sidebar-right" id="rightSidebar">
            <div class="sidebar-header">
                <span>🎨 Mermaid 流程图工坊</span>
                <span style="font-size:10px; color:#666;">自动同步: ON</span>
            </div>
            <div class="sidebar-body">
                <div class="mermaid-editor-box">
                    <div class="flow-controls">
                        <input type="text" id="nodeA" placeholder="节点A" style="width: 70px;">
                        <select id="linkType" style="width: 50px;">
                            <option value="-->">-></option>
                            <option value="-.->">.-></option>
                            <option value="==>">=></option>
                            <option value="-->|text|">--text--></option>
                        </select>
                        <input type="text" id="nodeB" placeholder="节点B" style="width: 70px;">
                        <button onclick="addFlowPath()">➕</button>
                    </div>
                    
                    <textarea id="mermaidEditor" class="code-box" oninput="syncEditorToView()">graph TD
    Start(开始) --> Check{{校验}}
    Check --> Compute[计算]
    Compute --> End(结束)</textarea>
                    
                    <button onclick="renderMermaidManual()" style="width:100%; background:var(--primary-color); color:white; border:none; padding:5px;">🔄 刷新预览</button>
                    <button onclick="insertMermaidFromEditor()" style="width:100%; background:#28a745; color:white; border:none; padding:5px; margin-top:5px;">✅ 插入到当前章节</button>
                    
                    <div id="sidebarPreview" class="mermaid-preview" style="zoom: 0.8;"></div>
                </div>
                
                <div class="guidance-box">
                    <b>提示：</b><br>
                    1. 在下方编辑流程图代码<br>
                    2. 点击"插入到当前章节"可将流程图插入到当前编辑的章节中<br>
                    3. 支持多种连接类型：--> (实线), -.- (虚线), == (粗线), --text--> (带文本)<br>
                    4. 快捷键：Ctrl+M 打开工具栏，Ctrl+Shift+M 切换工具栏
                </div>
            </div>
        </aside>
    </div>

    <script>
        // ================= 常量定义 =================
        const PARAM_TYPES = ["必选输入", "可选输入", "必选属性", "可选属性", "输出"];
        const BASE_TYPES = ["Tensor", "List[Tensor]", "int", "float", "bool", "str"];
        
        // 全局变量用于跟踪参数和自动补全
        let globalParamNames = [];
        let currentSectionId = null;
        let mermaidCounter = 0;

        // ================= 初始化 =================
        window.onload = function() {{
            mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
            generateTOC();
            if(document.querySelector('#protoTable tbody').rows.length === 0) addRow('protoTable');
            if(document.querySelector('#opapiTable tbody').rows.length === 0) addOpapiRow('opapiTable');
            
            // 初始化流程图同步
            syncEditorToView();
            
            // 初始化参数跟踪
            updateGlobalParamNames();
            
            // 初始化章节点击事件
            initializeSectionTracking();
        }};

        // ================= 1. 左右侧栏逻辑 =================
        function generateTOC() {{
            const toc = document.getElementById('toc');
            const headers = document.querySelectorAll('main h1, main h2, main h3');
            let html = '';
            headers.forEach(h => {{
                const isH1 = h.tagName === 'H1';
                const isH2 = h.tagName === 'H2';
                const cls = isH1 ? 'nav-item nav-h1' : (isH2 ? 'nav-item nav-h2' : 'nav-item nav-h3');
                html += `<div class="${{cls}}" onclick="scrollToSection('${{h.id}}')">${{h.innerText}}</div>`;
            }});
            toc.innerHTML = html;
        }}

        function scrollToSection(sectionId) {{
            document.getElementById(sectionId).scrollIntoView({{behavior: 'smooth'}});
            // 设置当前章节
            currentSectionId = sectionId;
        }}

        function toggleRightSidebar() {{
            const bar = document.getElementById('rightSidebar');
            bar.style.width = bar.style.width === '0px' ? '380px' : '0px';
        }}

        // ================= 2. 章节跟踪功能 =================
        function initializeSectionTracking() {{
            // 为所有可编辑区域添加点击事件
            const editableAreas = document.querySelectorAll('.editable-area');
            editableAreas.forEach(area => {{
                area.addEventListener('click', function() {{
                    const section = this.getAttribute('data-section');
                    if (section) {{
                        currentSectionId = section;
                        console.log('当前章节:', currentSectionId);
                    }}
                }});
                
                area.addEventListener('focus', function() {{
                    const section = this.getAttribute('data-section');
                    if (section) {{
                        currentSectionId = section;
                        console.log('当前章节:', currentSectionId);
                    }}
                }});
            }});
        }}

        // ================= 3. Mermaid 核心与同步逻辑 =================
        function syncEditorToView() {{
            const code = document.getElementById('mermaidEditor').value;
            
            // 1. 更新右侧预览
            const sideView = document.getElementById('sidebarPreview');
            sideView.innerHTML = code;
            sideView.removeAttribute('data-processed');
            
            // 2. 更新中间文档预览 (2.1章节)
            const mainView = document.getElementById('mainFlowchartDisplay');
            mainView.innerHTML = code;
            mainView.removeAttribute('data-processed');

            // 3. 更新隐藏域 (用于导出)
            document.getElementById('hiddenMermaidCode').value = code;

            try {{
                mermaid.run({{ nodes: [sideView, mainView] }});
            }} catch(e) {{ console.log(e); }}
        }}

        function renderMermaidManual() {{ syncEditorToView(); }}

        function addFlowPath() {{
            const A = document.getElementById('nodeA').value.trim();
            const B = document.getElementById('nodeB').value.trim();
            const type = document.getElementById('linkType').value;
            if(A && B) {{
                let line = `    ${{A}} `;
                if (type === '-->|text|') {{
                    line += `-->|${{A}}到${{B}}|`;
                }} else {{
                    line += type;
                }}
                line += ` ${{B}}`;
                
                const editor = document.getElementById('mermaidEditor');
                editor.value += '\\n' + line;
                syncEditorToView();
            }}
        }}

        // ================= 4. Mermaid插入功能（修复版）=====================
        function insertMermaidToSelection() {{
            toggleRightSidebar();
        }}

        function insertMermaidFromEditor() {{
            if (!currentSectionId) {{
                alert('请先点击要插入流程图的章节区域');
                return;
            }}
            
            const mermaidCode = document.getElementById('mermaidEditor').value;
            if (!mermaidCode.trim()) {{
                alert('请先编辑流程图代码');
                return;
            }}
            
            // 找到对应章节的编辑区域
            const targetElement = document.querySelector(`[data-section="${{currentSectionId}}"]`);
            if (!targetElement) {{
                alert('无法找到目标章节，请重新点击章节区域');
                return;
            }}
            
            // 创建流程图容器
            const mermaidContainer = document.createElement('div');
            mermaidContainer.className = 'mermaid-container';
            mermaidContainer.id = 'mermaid_dynamic_' + (++mermaidCounter);
            
            // 添加关闭按钮
            const closeBtn = document.createElement('button');
            closeBtn.className = 'mermaid-close';
            closeBtn.innerHTML = '×';
            closeBtn.onclick = function() {{
                mermaidContainer.remove();
            }};
            
            // 添加流程图内容
            const mermaidDiv = document.createElement('div');
            mermaidDiv.className = 'mermaid';
            mermaidDiv.innerHTML = mermaidCode;
            
            mermaidContainer.appendChild(closeBtn);
            mermaidContainer.appendChild(mermaidDiv);
            
            // 插入到编辑区域的后面
            targetElement.parentNode.insertBefore(mermaidContainer, targetElement.nextSibling);
            
            // 渲染流程图
            try {{
                mermaid.run({{ nodes: [mermaidDiv] }});
            }} catch(e) {{ 
                console.log(e); 
                alert('流程图渲染失败，请检查代码');
            }}
            
            // 关闭工具栏
            toggleRightSidebar();
            
            // 滚动到插入的流程图位置
            mermaidContainer.scrollIntoView({{behavior: 'smooth', block: 'center'}});
        }}

        // ================= 5. 参数跟踪和自动补全 =================
        function updateGlobalParamNames() {{
            // 从原型表中获取参数名
            const protoTable = document.getElementById('protoTable');
            const rows = protoTable.querySelectorAll('tbody tr');
            globalParamNames = [];
            rows.forEach(row => {{
                const nameInput = row.cells[0].querySelector('input');
                if (nameInput && nameInput.value.trim()) {{
                    globalParamNames.push(nameInput.value.trim());
                }}
            }});
        }}

        function checkAndAddNodeToFlow(row) {{
            const nameInput = row.cells[0].querySelector('input');
            const typeSelect = row.cells[1].querySelector('select');
            
            const name = nameInput.value.trim();
            const type = typeSelect.value;

            if (name && type.includes('输入')) {{
                const editor = document.getElementById('mermaidEditor');
                let code = editor.value;

                if (!code.includes(name)) {{
                    const newNodeLine = `    ${{name}}(${{name}}) -.-> Start`;
                    const lines = code.split('\\n');
                    if(lines.length > 0) {{
                        lines.splice(1, 0, newNodeLine);
                        editor.value = lines.join('\\n');
                        syncEditorToView();
                    }}
                }}
            }}
            
            // 更新全局参数列表
            updateGlobalParamNames();
        }}

        function autoCompleteTestCase(inputElement, paramName) {{
            if (!paramName) return;
            
            const row = inputElement.parentNode.parentNode;
            const testCaseCell = row.cells[1];
            const testCaseInput = testCaseCell.querySelector('input');
            
            // 获取当前值
            let currentValue = testCaseInput.value.trim();
            
            // 如果当前值为空或只包含自动补全的内容，则替换
            if (!currentValue || currentValue.includes('[shape],[dtype]')) {{
                const autoCompleteText = `${{paramName}}[shape],[dtype];`;
                testCaseInput.value = autoCompleteText;
                
                // 添加视觉提示
                const suggestSpan = document.createElement('span');
                suggestSpan.className = 'auto-suggest';
                suggestSpan.textContent = ' (自动补全)';
                testCaseInput.parentNode.appendChild(suggestSpan);
                
                // 3秒后移除提示
                setTimeout(() => {{
                    if (suggestSpan.parentNode) {{
                        suggestSpan.remove();
                    }}
                }}, 3000);
            }}
        }}

        // ================= 6. 表格逻辑 =================
        function createSelect(options, selectedValue, onChangeCode) {{
            let html = `<select onchange="${{onChangeCode}}">`;
            options.forEach(opt => {{
                const selected = (opt === selectedValue) ? 'selected' : '';
                html += `<option value="${{opt}}" ${{selected}}>${{opt}}</option>`;
            }});
            html += '</select>';
            return html;
        }}

        function addRow(tableId, data = null) {{
            const tbody = document.querySelector(`#${{tableId}} tbody`);
            const row = tbody.insertRow();
            const d = data || {{ name: '', type: '必选输入', default: '', baseType: 'Tensor', spec: '', info: '' }};
            
            row.insertCell(0).innerHTML = `<input type="text" value="${{d.name}}" placeholder="Name" onblur="checkAndAddNodeToFlow(this.parentNode.parentNode); updateGlobalParamNames();">`;
            row.insertCell(1).innerHTML = createSelect(PARAM_TYPES, d.type, "checkAndAddNodeToFlow(this.parentNode.parentNode)");
            row.insertCell(2).innerHTML = `<input type="text" value="${{d.default}}" placeholder="None">`;
            row.insertCell(3).innerHTML = createSelect(BASE_TYPES, d.baseType, "");
            row.insertCell(4).innerHTML = `<textarea placeholder="fp16:[ND]">${{d.spec}}</textarea>`;
            row.insertCell(5).innerHTML = `<textarea>${{d.info}}</textarea>`;
            row.insertCell(6).innerHTML = `<button onclick="this.parentNode.parentNode.remove(); updateGlobalParamNames();" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button>`;
        }}

        function addOpapiRow(tableId, data = null) {{
            const tbody = document.querySelector(`#${{tableId}} tbody`);
            const row = tbody.insertRow();
            const d = data || {{ name: '', params: '', return: '', desc: '' }};
            
            row.insertCell(0).innerHTML = `<input type="text" value="${{d.name}}" placeholder="接口名称">`;
            row.insertCell(1).innerHTML = `<textarea placeholder="参数列表">${{d.params}}</textarea>`;
            row.insertCell(2).innerHTML = `<input type="text" value="${{d.return}}" placeholder="返回值">`;
            row.insertCell(3).innerHTML = `<textarea placeholder="功能说明">${{d.desc}}</textarea>`;
            row.insertCell(4).innerHTML = `<button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button>`;
        }}

        function addTilingRow(tableId, data = null) {{
            const tbody = document.querySelector(`#${{tableId}} tbody`);
            const row = tbody.insertRow();
            const d = data || {{ name: '', meaning: '', boundary: '' }};
            
            row.insertCell(0).innerHTML = `<input type="text" value="${{d.name}}" placeholder="变量名">`;
            row.insertCell(1).innerHTML = `<textarea placeholder="语义描述">${{d.meaning}}</textarea>`;
            row.insertCell(2).innerHTML = `<textarea placeholder="设计边界">${{d.boundary}}</textarea>`;
            row.insertCell(3).innerHTML = `<button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button>`;
        }}

        function addWhiteBoxRow(tableId) {{
            const tbody = document.querySelector(`#${{tableId}} tbody`);
            const row = tbody.insertRow();
            
            const scenarioCell = row.insertCell(0);
            const testCaseCell = row.insertCell(1);
            const remarkCell = row.insertCell(2);
            const deleteCell = row.insertCell(3);
            
            scenarioCell.innerHTML = '<input type="text" placeholder="验证场景" onblur="autoCompleteTestCase(this, this.value)">';
            testCaseCell.innerHTML = '<input type="text" placeholder="验证用例">';
            remarkCell.innerHTML = '<input type="text" placeholder="备注">';
            deleteCell.innerHTML = '<button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button>';
        }}

        function addChecklistRow(tableId) {{
            const tbody = document.querySelector(`#${{tableId}} tbody`);
            const row = tbody.insertRow();
            
            row.insertCell(0).innerHTML = '<input type="checkbox">';
            row.insertCell(1).innerHTML = '<input type="text" placeholder="交付件名称">';
            row.insertCell(2).innerHTML = '<input type="text" placeholder="负责人">';
            row.insertCell(3).innerHTML = `
                <select>
                    <option value="已完成">已完成</option>
                    <option value="进行中">进行中</option>
                    <option value="未开始">未开始</option>
                </select>
            `;
            row.insertCell(4).innerHTML = '<input type="text" placeholder="备注信息">';
            row.insertCell(5).innerHTML = `<button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button>`;
        }}

        function addSimpleRow(tableId) {{
            const tbody = document.querySelector(`#${{tableId}} tbody`);
            const row = tbody.insertRow();
            const cellCount = row.cells.length || 3;
            
            for (let i = 0; i < cellCount - 1; i++) {{
                row.insertCell(i).innerHTML = '<input type="text" placeholder="">';
            }}
            
            if (cellCount > 0) {{
                const lastCell = row.insertCell(cellCount - 1);
                lastCell.innerHTML = '<button onclick="this.parentNode.parentNode.remove()" style="color:red;border:none;background:none;cursor:pointer;">🗑️</button>';
            }}
        }}

        // ================= 7. 导出逻辑 =================
        function elementToMarkdown(node) {{
            if (node.nodeType === Node.TEXT_NODE) return node.textContent;
            if (node.nodeType === Node.ELEMENT_NODE) {{
                if (node.tagName === 'DIV' || node.tagName === 'P') {{
                    let childContent = "";
                    node.childNodes.forEach(child => {{ childContent += elementToMarkdown(child); }});
                    return "\\n" + childContent + "\\n"; 
                }}
                if (node.tagName === 'BR') return "\\n";
                let markdown = "";
                node.childNodes.forEach(child => {{ markdown += elementToMarkdown(child); }});
                return markdown;
            }}
            return "";
        }}

        function tableToMarkdown(tableId) {{
            const table = document.getElementById(tableId);
            if (!table) return "";
            
            let md = "";
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {{
                const inputs = row.querySelectorAll('input, select, textarea');
                let line = "|";
                inputs.forEach(i => {{
                    let value = '';
                    if (i.type === 'checkbox') {{
                        value = i.checked ? '√' : ' ';
                    }} else {{
                        value = i.value.replace(/\\n/g,'<br>');
                    }}
                    line += ` ${{value}} |`;
                }});
                md += line + "\\n";
            }});
            return md;
        }}

        function exportMarkdown() {{
            let md = "# 算子设计文档 (V6.0)\\n\\n";
            
            // 1.1 需求背景
            md += "## 1.1 需求背景\\n" + elementToMarkdown(document.getElementById('content_1_1')) + "\\n\\n";
            
            // 1.2 功能分析
            md += "## 1.2 功能分析\\n\\n### - 接口功能\\n";
            md += elementToMarkdown(document.getElementById('content_1_2_func')) + "\\n\\n";
            md += "### - 计算公式\\n";
            md += elementToMarkdown(document.getElementById('content_1_2_formula')) + "\\n\\n";
            
            // 原型设计表格
            md += "### - 原型设计\\n";
            md += "| 参数名 | 类型 | 默认值 | 基础类型 | 规格 | 说明 |\\n|---|---|---|---|---|---|\\n";
            md += tableToMarkdown('protoTable') + "\\n";
            
            // 原型约束
            md += "### - 原型约束\\n";
            md += elementToMarkdown(document.getElementById('content_1_2_const')) + "\\n\\n";
            
            // 1.3 对标分析
            md += "## 1.3 对标分析\\n";
            md += elementToMarkdown(document.getElementById('content_1_3')) + "\\n\\n";
            
            // 2. 特性实现方案
            md += "# 2. 特性实现方案\\n\\n";
            
            // 2.1 算子整体计算流程图
            md += "## 2.1 算子整体计算流程图\\n\\n\\`\\`\\`mermaid\\n";
            md += document.getElementById('hiddenMermaidCode').value;
            md += "\\n\\`\\`\\`\\n\\n";
            
            // 2.2 ACLNN接口设计
            md += "## 2.2 ACLNN接口设计\\n\\n";
            md += "| 接口名称 | 参数列表 | 返回值 | 功能说明 |\\n|---|---|---|---|\\n";
            md += tableToMarkdown('opapiTable') + "\\n";
            md += elementToMarkdown(document.getElementById('content_2_2')) + "\\n\\n";
            
            // 2.3 Infershape
            md += "## 2.3 Infershape设计\\n";
            md += elementToMarkdown(document.getElementById('content_2_3')) + "\\n\\n";
            
            // 2.4 Tiling
            md += "## 2.4 Tiling设计\\n";
            md += "| 变量名 | 语义 | 设计边界 |\\n|---|---|---|\\n";
            md += tableToMarkdown('tilingTable') + "\\n";
            md += elementToMarkdown(document.getElementById('content_2_4')) + "\\n\\n";
            
            // 2.5 片上内存
            md += "## 2.5 片上内存资源设计\\n";
            md += elementToMarkdown(document.getElementById('content_2_5')) + "\\n\\n";
            
            // 2.6 Kernel
            md += "## 2.6 Kernel方案\\n";
            md += elementToMarkdown(document.getElementById('content_2_6')) + "\\n\\n";
            
            // 3. 其他算子交付件
            md += "# 3. 其他算子交付件\\n";
            md += elementToMarkdown(document.getElementById('content_3')) + "\\n\\n";
            
            // 3.1 Checklist
            md += "## 3.1 交付件Checklist\\n\\n";
            md += "| ✓ | 交付件名称 | 负责人 | 完成状态 | 备注 |\\n|---|---|---|---|---|\\n";
            md += tableToMarkdown('checklistTable') + "\\n\\n";
            
            // 4. 测试设计
            md += "# 4. 测试设计\\n\\n";
            
            // 4.1 测试标杆
            md += "## 4.1 测试标杆\\n";
            md += elementToMarkdown(document.getElementById('content_4_1')) + "\\n\\n";
            
            // 4.2 测试用例设计
            md += "## 4.2 测试用例设计\\n\\n";
            
            // 4.2.1 白盒用例
            md += "### 4.2.1 白盒用例\\n";
            md += "| 验证场景 | 验证用例 | 备注 |\\n|---|---|---|\\n";
            md += tableToMarkdown('whiteBoxTable') + "\\n";
            
            // 4.2.2 性能用例
            md += "### 4.2.2 性能用例\\n";
            md += "| 验证项 | 用例数 | 备注 |\\n|---|---|---|\\n";
            md += tableToMarkdown('perfTable') + "\\n";
            
            // 5. 遗留问题
            md += "# 5. 遗留问题\\n";
            md += elementToMarkdown(document.getElementById('content_5')) + "\\n";
            
            const blob = new Blob([md], {{ type: 'text/markdown' }});
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'Design_Doc_V6_0.md';
            a.click();
        }}

        function importMarkdown(input) {{
            alert("导入功能在 V6.0 版本中暂简化，请手动复制内容。");
        }}

        // 添加键盘快捷键支持
        document.addEventListener('keydown', function(e) {{
            // Ctrl+M 快速插入流程图
            if (e.ctrlKey && e.key === 'm') {{
                e.preventDefault();
                insertMermaidToSelection();
            }}
            
            // Ctrl+Shift+M 切换工具栏
            if (e.ctrlKey && e.shiftKey && e.key === 'M') {{
                e.preventDefault();
                toggleRightSidebar();
            }}
        }});
    </script>
</body>
</html>'''


def generate_design_doc_template(project_name="OperatorProject", output_dir="./output"):
    """
    生成算子设计文档HTML文件
    
    参数:
        project_name: 项目名称
        output_dir: 输出目录
    
    返回:
        生成的文件路径
    """
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    # 生成文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"operator_design_doc_{timestamp}.html"
    filepath = os.path.join(output_dir, filename)
    
    # 获取HTML内容并替换项目名称
    html_content = get_html_template()
    html_content = html_content.format(project_name=project_name)
    
    # 写入文件
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    return filepath