from .generate_design_doc_template import generate_design_doc_template

# 将核心功能导出，方便外部调用
__all__ = ['generate_design_doc_template']