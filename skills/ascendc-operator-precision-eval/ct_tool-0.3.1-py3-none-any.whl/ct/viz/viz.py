import numpy as np
import matplotlib.pyplot as plt
import os
import datetime
from ct.utils import common

# 解决字体显示问题
plt.rcParams['axes.unicode_minus'] = False  # 使用ASCII减号代替Unicode减号
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Bitstream Vera Sans', 'sans-serif']  # 设置默认字体

# 尝试导入 bfloat16ext
try:
    import bfloat16ext
except ImportError:
    bfloat16ext = None

# === 辅助函数区域 ===

def ensure_dir(directory):
    if not os.path.exists(directory):
        try:
            os.makedirs(directory)
        except OSError as e:
            common.print_log_error(f"Error creating directory {directory}: {e}")

def cal_relative_diff_np(real_data, expect_data, diff_thd=0.001):
    a = np.abs(np.subtract(real_data, expect_data))
    b1 = np.maximum(np.abs(real_data), (np.abs(expect_data)))
    b2 = float((1.0 / (1 << 14)) / diff_thd) 
    b = np.add(np.maximum(b1, b2), 10e-10)
    result = np.where(a < diff_thd, a, a / b)
    return result

# === 绘图核心逻辑 (已修改) ===

def _save_plot_single_precision(name, real_data_in, expect_data_in, output_dir, filename_prefix, diff_thd):
    """
    内部绘图函数：处理扁平化后的 float 数据并生成图表
    修改注：已移除所有采样和Step逻辑，全量绘制。
    """
    
    # 确保在创建图表前设置字体参数
    plt.rcParams.update({
        'axes.unicode_minus': False,  # 使用ASCII减号代替Unicode减号
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'DejaVu Sans', 'Bitstream Vera Sans', 'sans-serif'],
        'mathtext.default': 'regular'  # 使用常规文本而非数学符号
    })
    
    # 1. 数据预处理
    real_flat = real_data_in.flatten().astype(np.float32)
    expect_flat = expect_data_in.flatten().astype(np.float32)

    if real_flat.size != expect_flat.size:
        common.print_log_error(f"Size mismatch in visualization: {real_flat.size} vs {expect_flat.size}")
        return

    # 2. 计算误差
    abs_diff = np.abs(real_flat - expect_flat)
    rel_diff = cal_relative_diff_np(real_flat, expect_flat, diff_thd)
    
    # 3. 创建画布
    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    fig.suptitle(f'Precision Visualization: {filename_prefix} [{name}]', fontsize=16)

    # --- 子图 1: 拟合散点图 (Scatter Plot) ---
    ax1 = axes[0, 0]
    # [修改] 移除 if len > 5000 的判断，直接绘制所有点
    # s=1 将点设置得更小一点，因为数据量可能很大
    ax1.scatter(expect_flat, real_flat, alpha=0.5, s=1, c='blue', label='All Data')
    
    lims = [
        np.min([ax1.get_xlim(), ax1.get_ylim()]),
        np.max([ax1.get_xlim(), ax1.get_ylim()]),
    ]
    ax1.plot(lims, lims, 'r--', alpha=0.75, zorder=0, label='Ideal (y=x)')
    ax1.set_xlabel('Expect Data (CPU)')
    ax1.set_ylabel('Real Data (NPU)')
    ax1.set_title(f'Value Fitting (Total: {len(real_flat)})')
    ax1.legend()
    ax1.grid(True, linestyle='--', alpha=0.5)

    # --- 子图 2: 绝对误差分布 (Histogram) ---
    ax2 = axes[0, 1]
    # 直方图本身就是统计分布，不需要降采样
    ax2.hist(abs_diff, bins=50, color='orange', alpha=0.7, log=True)
    ax2.set_title('Absolute Diff Distribution (Log Scale)')
    ax2.set_xlabel('Absolute Error')
    ax2.set_ylabel('Count (Log)')
    ax2.grid(True, linestyle='--', alpha=0.3)

    # --- 子图 3: 误差综合分析 (合并绝对误差和相对误差) ---
    ax3 = axes[1, 0]
    
    # 计算特殊情况的掩码
    # 情况1：绝对误差小(<0.1%阈值)但相对误差大(>阈值)
    mask_abs_small_rel_large = (abs_diff < diff_thd * 0.001) & (rel_diff > diff_thd)
    # 情况2：绝对误差大(>阈值)但相对误差小(<阈值) - 修改：放宽相对误差条件
    mask_abs_large_rel_small = (abs_diff > diff_thd) & (rel_diff < diff_thd)
    # 情况3：真正的异常点(相对误差>阈值)且不属于情况1
    mask_abnormal = (rel_diff > diff_thd) & ~mask_abs_small_rel_large
    # 情况4：正常点
    mask_normal = rel_diff <= diff_thd
    
    # 绘制正常点（背景，半透明）
    if np.any(mask_normal):
        ax3.scatter(np.where(mask_normal)[0], abs_diff[mask_normal], 
                   color='lightgray', s=1, alpha=0.2, label='Normal (Rel ≤ Thd)')
        ax3.scatter(np.where(mask_normal)[0], rel_diff[mask_normal], 
                   color='lightgreen', s=1, alpha=0.2)
    
    # 绘制特殊情况1：绝对误差小但相对误差大
    if np.any(mask_abs_small_rel_large):
        ax3.scatter(np.where(mask_abs_small_rel_large)[0], abs_diff[mask_abs_small_rel_large], 
                   color='blue', s=8, alpha=1, label='Abs Small but Rel Large')
        ax3.scatter(np.where(mask_abs_small_rel_large)[0], rel_diff[mask_abs_small_rel_large], 
                   color='blue', s=8, alpha=1)
    
    # 绘制特殊情况2：绝对误差大但相对误差小
    if np.any(mask_abs_large_rel_small):
        ax3.scatter(np.where(mask_abs_large_rel_small)[0], abs_diff[mask_abs_large_rel_small], 
                   color='purple', s=8, alpha=1, label='Abs Large but Rel Small')
        ax3.scatter(np.where(mask_abs_large_rel_small)[0], rel_diff[mask_abs_large_rel_small], 
                   color='purple', s=8, alpha=1)
    
    # 绘制真正的异常点（相对误差>阈值）
    if np.any(mask_abnormal):
        ax3.scatter(np.where(mask_abnormal)[0], abs_diff[mask_abnormal], 
                   color='red', s=12, alpha=1.0, label='Abnormal (Rel > Thd)')
        ax3.scatter(np.where(mask_abnormal)[0], rel_diff[mask_abnormal], 
                   color='red', s=12, alpha=1.0)
    
    # 添加阈值线
    ax3.axhline(y=diff_thd, color='black', linestyle='--', label=f'Threshold={diff_thd}')
    
    # 设置双Y轴
    ax3.set_xlabel('Flatten Index')
    ax3.set_ylabel('Absolute Diff', color='black')
    ax3.tick_params(axis='y', labelcolor='black')
    
    ax3_right = ax3.twinx()
    ax3_right.set_ylabel('Relative Diff', color='green')
    ax3_right.tick_params(axis='y', labelcolor='green')
    
    ax3.set_title('Error Analysis (Abs & Rel Diff)')
    ax3.grid(True, linestyle='--', alpha=0.3)
    
    # 合并图例
    lines, labels = ax3.get_legend_handles_labels()
    ax3.legend(lines, labels, loc='upper right', fontsize=8)
    
    # --- 子图 4: 误差散点图（绝对误差 vs 相对误差） ---
    ax4 = axes[1, 1]
    
    # 使用不同颜色和大小标记不同类型的点
    # 正常点
    if np.any(mask_normal):
        ax4.scatter(abs_diff[mask_normal], rel_diff[mask_normal], 
                   color='lightgray', s=5, alpha=0.2, label='Normal')
    
    # 特殊情况1
    if np.any(mask_abs_small_rel_large):
        ax4.scatter(abs_diff[mask_abs_small_rel_large], rel_diff[mask_abs_small_rel_large], 
                   color='blue', s=30, alpha=0.8, label='Abs Small, Rel Large')
    
    # 特殊情况2
    if np.any(mask_abs_large_rel_small):
        ax4.scatter(abs_diff[mask_abs_large_rel_small], rel_diff[mask_abs_large_rel_small], 
                   color='purple', s=30, alpha=0.8, label='Abs Large, Rel Small')
    
    # 真正的异常点
    if np.any(mask_abnormal):
        ax4.scatter(abs_diff[mask_abnormal], rel_diff[mask_abnormal], 
                   color='red', s=50, alpha=1.0, label='Abnormal')
    
    # 添加阈值线
    ax4.axhline(y=diff_thd, color='black', linestyle='--', label=f'Rel Threshold={diff_thd}')
    
    # 添加横坐标辅助线，用于区别绝对误差小的场景
    # 选择一个合适的绝对误差阈值，这里使用diff_thd * 0.001作为参考
    abs_threshold = diff_thd
    ax4.axvline(x=abs_threshold, color='gray', linestyle='--', label=f'Abs Threshold={abs_threshold:.2e}')
    
    ax4.set_title('Abs Diff vs Rel Diff Scatter')
    ax4.set_xlabel('Absolute Difference')
    ax4.set_ylabel('Relative Difference')
    ax4.set_xscale('log')
    ax4.set_yscale('log')
    ax4.grid(True, linestyle='--', alpha=0.3)
    ax4.legend(fontsize=8)

    # 4. 保存图片
    ensure_dir(output_dir)
    save_path = os.path.join(output_dir, f"{filename_prefix}_{name}.png")
    
    try:
        plt.tight_layout()
        plt.savefig(save_path, dpi=150)
        plt.close(fig)
        common.print_log(f"图表已保存至: {save_path}")
    except Exception as e:
        common.print_log_error(f"Failed to save plot: {e}")

# === 核心入口函数 (保持不变) ===

def plot_diff(npu_output, cpu_output, output_dir="ct/viz_result", filename_prefix="diff_viz", diff_thd=0.001):
    if isinstance(npu_output, list):
        npu_output = np.array(npu_output)
    if isinstance(cpu_output, list):
        cpu_output = np.array(cpu_output)
    
    try:
        if hasattr(npu_output, 'dtype') and npu_output.dtype == "|V2" and bfloat16ext:
            npu_output.dtype = "bfloat16"
    except Exception:
        pass

    full_prefix = f"{filename_prefix}"

    # 打印四张图的含义
    common.print_log("=" * 80)
    common.print_log("可视化图表说明：")
    common.print_log(f"阈值: {diff_thd}")
    common.print_log("=" * 80)
    common.print_log("1. 拟合散点图 (Scatter Plot)")
    common.print_log("   - X轴: CPU输出数据（期望值）")
    common.print_log("   - Y轴: NPU输出数据（实际值）")
    common.print_log("   - 蓝色点: 所有数据点的分布")
    common.print_log("   - 红色虚线: 理想拟合线(y=x)，表示完全匹配的情况")
    common.print_log("   - 解读: 数据点越接近红色虚线，说明NPU和CPU输出越匹配")
    common.print_log("-" * 80)
    common.print_log("2. 绝对误差分布 (Histogram)")
    common.print_log("   - X轴: 绝对误差值（|NPU输出 - CPU输出|）")
    common.print_log("   - Y轴: 具有该误差值的数据点数量（对数刻度）")
    common.print_log("   - 解读: 直方图的峰值位置表示最常见的误差大小，对数刻度有助于观察小概率的大误差情况")
    common.print_log("-" * 80)
    common.print_log("3. 误差综合分析图")
    common.print_log("   - X轴: 数据点的扁平化索引")
    common.print_log("   - 左侧Y轴: 绝对误差（黑色）")
    common.print_log("   - 右侧Y轴: 相对误差（绿色）")
    common.print_log("   - 灰色点: 正常数据点（相对误差≤阈值）")
    common.print_log("   - 蓝色点: 绝对误差小但相对误差大的点")
    common.print_log("   - 紫色点: 绝对误差大但相对误差小的点")
    common.print_log("   - 红色点: 真正的异常点（相对误差>阈值）")
    common.print_log("   - 解读: 可同时观察绝对误差和相对误差的变化趋势，快速识别特殊情况和异常点")
    common.print_log("-" * 80)
    common.print_log("4. 误差散点图（绝对误差 vs 相对误差）")
    common.print_log("   - X轴: 绝对误差值（对数刻度）")
    common.print_log("   - Y轴: 相对误差值（对数刻度）")
    common.print_log("   - 灰色点: 正常数据点")
    common.print_log("   - 蓝色点: 绝对误差小但相对误差大的点")
    common.print_log("   - 紫色点: 绝对误差大但相对误差小的点")
    common.print_log("   - 红色点: 真正的异常点")
    common.print_log("   - 解读: 直观展示绝对误差和相对误差之间的关系，识别数据中的特殊模式和异常情况")
    common.print_log("=" * 80)
    
    if np.iscomplexobj(npu_output) or np.iscomplexobj(cpu_output):
        common.print_log("检测到复数数据，将生成[实部]和[虚部]两张图表...")
        _save_plot_single_precision("RealPart", np.real(npu_output), np.real(cpu_output), output_dir, full_prefix, diff_thd)
        _save_plot_single_precision("ImagPart", np.imag(npu_output), np.imag(cpu_output), output_dir, full_prefix, diff_thd)
    else:
        _save_plot_single_precision("Standard", npu_output, cpu_output, output_dir, full_prefix, diff_thd)