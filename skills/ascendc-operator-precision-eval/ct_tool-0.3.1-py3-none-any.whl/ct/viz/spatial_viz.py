import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os
from ct.utils import common

# 解决字体显示问题
plt.rcParams['axes.unicode_minus'] = False  # 使用ASCII减号代替Unicode减号
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Bitstream Vera Sans', 'sans-serif'] 

def ensure_dir(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def _get_worst_slice_2d(diff_tensor, real_shape):
    """
    (保持不变) 获取 2D 视图用于可视化
    """
    ndim = len(real_shape)
    
    if ndim < 2:
        side = int(np.ceil(np.sqrt(real_shape[0])))
        padded = np.zeros(side * side, dtype=diff_tensor.dtype)
        padded[:real_shape[0]] = diff_tensor
        return padded.reshape(side, side), f"Reshaped 1D->2D ({side}x{side})"
    
    elif ndim == 2:
        return diff_tensor, "Original 2D"
    
    else:
        front_dims = real_shape[:-2]
        new_rows = int(np.prod(front_dims))
        back_dims = real_shape[-2:]
        new_cols = int(np.prod(back_dims))
        flattened_view = diff_tensor.reshape(new_rows, new_cols)
        info_str = f"Global View: Dims {front_dims}->Row({new_rows}), Dims {back_dims}->Col({new_cols})"
        return flattened_view, info_str

def plot_spatial_error(real_data, expect_data, output_dir="ct/viz_result", filename_prefix="spatial", diff_thd=0.001, use_log=True):
    """
    空间误差可视化分析 (增强版)
    功能：
    1. 热力图：展示绝对误差 (Abs Diff)。
    2. 边缘直方图：同时展示 绝对误差累积 (Abs Sum) 和 净误差累积 (Net Sum)。
    """
    try:
        # 1. 基础数据准备
        # 为了计算净误差，必须使用带符号的 float
        if np.iscomplexobj(real_data) or np.iscomplexobj(expect_data):
            # 复数情况：净误差定义比较模糊，这里暂时只取实部差异作为净误差演示，或者仅用模长
            # 这里保持原逻辑：热力图用模长，但为了支持净误差，我们暂且只处理实数场景或取实部
            diff_raw_signed = (real_data - expect_data).real # 降级处理
            abs_diff = np.abs(real_data - expect_data)
        else:
            real_f = real_data.astype(np.float32)
            expect_f = expect_data.astype(np.float32)
            diff_raw_signed = real_f - expect_f  # 带符号误差 (Real - Expect)
            abs_diff = np.abs(diff_raw_signed)   # 绝对误差

        common.print_log(f"配置提醒: 分析模式 [Abs vs Net Error] (阈值: {diff_thd})")

        # 2. 过滤噪声 (基于绝对值阈值)
        # mask: 标记误差显著的位置
        error_mask = abs_diff > diff_thd
        
        # target_diff_abs: 用于热力图 (仅保留显著误差的绝对值)
        target_diff_abs = np.where(error_mask, abs_diff, 0)
        
        # target_diff_net: 用于计算净误差 (仅保留显著误差的带符号值)
        target_diff_net = np.where(error_mask, diff_raw_signed, 0)
        
    except Exception as e:
        print(f"[!] Error calculating diff: {e}")
        return

    # 3. 获取最差切片 (Abs 和 Net 使用相同的 reshape 逻辑)
    # diff_2d_abs 用于画热力图
    diff_2d_abs, slice_info = _get_worst_slice_2d(target_diff_abs, real_data.shape)
    
    # diff_2d_net 用于计算边缘统计 (形状必须和 abs 一致)
    diff_2d_net, _ = _get_worst_slice_2d(target_diff_net, real_data.shape)
    
    if np.max(diff_2d_abs) == 0:
        common.print_log(f"没有发现超过阈值 {diff_thd} 的误差，跳过空间分析。")
        return

    # --- 统计计算 ---
    # 绝对误差累积 (原来的逻辑)
    col_abs_sum = np.sum(diff_2d_abs, axis=0)
    row_abs_sum = np.sum(diff_2d_abs, axis=1)
    
    # [新增] 净误差累积 (带符号求和)
    col_net_sum = np.sum(diff_2d_net, axis=0)
    row_net_sum = np.sum(diff_2d_net, axis=1)

    # 基础统计
    total_samples = diff_2d_abs.size
    error_samples_count = np.count_nonzero(diff_2d_abs)
    mean_error_val = np.mean(diff_2d_abs[diff_2d_abs > 0]) if error_samples_count > 0 else 0
    max_error_val = np.max(diff_2d_abs)

    # --- 打印报告 ---
    common.print_log("=" * 60)
    common.print_log(f"{'空间误差分析报告 (SPATIAL REPORT)':^50}")
    common.print_log("=" * 60)
    common.print_log(f"[-] 全局统计:")
    common.print_log(f"    {'Max Abs Error':<15}: {max_error_val:.6f}")
    common.print_log(f"    {'Mean Abs Error':<15}: {mean_error_val:.6f}")
    
    # 打印净误差偏差最大的列
    max_bias_col_idx = np.argmax(np.abs(col_net_sum))
    common.print_log(f"[-] 偏差分析 (Bias Analysis):")
    common.print_log(f"    {'最大列偏差':<15}: 列 {max_bias_col_idx}")
    common.print_log(f"    {'  Abs Sum':<15}: {col_abs_sum[max_bias_col_idx]:.4f} (总震荡)")
    common.print_log(f"    {'  Net Sum':<15}: {col_net_sum[max_bias_col_idx]:.4f} (净偏移)")
    common.print_log("=" * 60)

    # --- 绘图 ---
    fig = plt.figure(figsize=(14, 10))
    gs = gridspec.GridSpec(4, 4, figure=fig, wspace=0.05, hspace=0.05)
    
    ax_main = fig.add_subplot(gs[1:4, 0:3])
    ax_top = fig.add_subplot(gs[0, 0:3], sharex=ax_main)
    ax_right = fig.add_subplot(gs[1:4, 3], sharey=ax_main)
    
    # 1. Main Heatmap (依然展示绝对误差，因为热力图不适合展示正负交替)
    im = ax_main.imshow(diff_2d_abs, cmap='hot', aspect='auto', interpolation='nearest', vmin=0, vmax=max_error_val)
    ax_main.set_title(f"Absolute Error Heatmap\n{slice_info}", fontsize=12)
    ax_main.set_xlabel("Dimension -1 (Width)")
    ax_main.set_ylabel("Dimension -2 (Height)")
    
    # -------------------------------------------------------------------------
    # 2. Top Hist (Column Analysis) - 双柱状图
    # -------------------------------------------------------------------------
    x_axis = range(len(col_abs_sum))
    # 绘制绝对误差 (背景，浅色)
    ax_top.bar(x_axis, col_abs_sum, color='lightgray', alpha=0.8, width=1.0, label='Abs Sum (Mag)')
    # 绘制净误差 (前景，深色，支持负数)
    # 使用 step 或 bar 都可以，这里用 bar，颜色区分正负
    colors = ['red' if x >= 0 else 'blue' for x in col_net_sum]
    ax_top.bar(x_axis, col_net_sum, color=colors, alpha=0.6, width=0.6, label='Net Sum (Bias)')
    
    ax_top.set_ylabel("Error Sum")
    ax_top.tick_params(axis='x', labelbottom=False)
    ax_top.legend(loc='upper right', fontsize='small')
    ax_top.grid(True, linestyle='--', alpha=0.3)
    
    # Log 处理 (Symlog 支持负数)
    if use_log and np.max(col_abs_sum) > 10:
        ax_top.set_yscale('symlog', linthresh=1e-5) # linthresh 防止 0 附近的对数爆炸

    # -------------------------------------------------------------------------
    # 3. Right Hist (Row Analysis) - 双柱状图
    # -------------------------------------------------------------------------
    y_axis = range(len(row_abs_sum))
    # 绘制绝对误差
    ax_right.barh(y_axis, row_abs_sum, color='lightgray', alpha=0.8, height=1.0, label='Abs Sum')
    # 绘制净误差
    colors_h = ['red' if x >= 0 else 'blue' for x in row_net_sum]
    ax_right.barh(y_axis, row_net_sum, color=colors_h, alpha=0.6, height=0.6, label='Net Sum')
    
    ax_right.set_xlabel("Error Sum")
    ax_right.tick_params(axis='y', labelleft=False)
    ax_right.set_ylim(ax_main.get_ylim()) # 对齐 Y 轴
    # ax_right.legend(loc='lower right', fontsize='small') # 空间可能不够，视情况开启
    ax_right.grid(True, linestyle='--', alpha=0.3)
    
    # Log 处理
    if use_log and np.max(row_abs_sum) > 10:
        ax_right.set_xscale('symlog', linthresh=1e-5)

    # Colorbar
    cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(im, cax=cbar_ax, label='Absolute Error Value')

    ensure_dir(output_dir)
    save_path = os.path.join(output_dir, f"{filename_prefix}_spatial_bias.png")
    plt.savefig(save_path, dpi=120, bbox_inches='tight')
    plt.close(fig)
    common.print_log(f"空间偏差分析图已保存至: {save_path}")