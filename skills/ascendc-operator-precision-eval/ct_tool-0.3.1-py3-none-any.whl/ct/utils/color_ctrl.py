import re
import ct.utils.common as common
class DualLogger:
    """双写日志记录器：同时输出到控制台(带颜色)和文件(纯文本)"""
    def __init__(self, log_file: str = "dual_benchmark_report.log"):
        self.log_file = log_file
        self.ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        
        # 初始化时清空旧日志，并写入Header
        try:
            with open(self.log_file, 'w', encoding='utf-8') as f:
                f.write(f"=== Dual Benchmark Report ===\n")
            common.print_log(f"日志文件将保存至: {self.log_file}")
        except Exception as e:
            common.print_log(f"[Warning] 无法创建日志文件: {e}")
            self.log_file = None

    def log(self, msg: str):
        # 1. 打印到控制台 (保持原有颜色)
        common.print_log(msg)
        
        # 2. 写入文件 (去除颜色代码)
        if self.log_file:
            clean_msg = self.ansi_escape.sub('', msg)
            try:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    f.write(clean_msg + "\n")
            except:
                pass