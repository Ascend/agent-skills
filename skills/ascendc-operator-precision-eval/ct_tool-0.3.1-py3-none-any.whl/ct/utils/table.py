import sys
import unicodedata

# common.py
from .common import print_log

def get_display_width(text):
    """
    计算字符串的显示宽度 (Visual Width)
    中文/全角字符 = 2
    英文/半角字符 = 1
    """
    width = 0
    for char in str(text):
        # 'W' = Wide (宽), 'F' = Fullwidth (全角)
        if unicodedata.east_asian_width(char) in ('F', 'W'):
            width += 2
        else:
            width += 1
    return width

class TablePrinter:
    """
    进阶版 ASCII 表格打印工具 (支持中英文混合对齐)
    """
    def __init__(self, col_widths, indent=2):
        """
        :param col_widths: list[int], 定义每一列的净宽度（应当足够宽以容纳内容）
        :param indent: int, 左侧缩进
        """
        self.col_widths = col_widths
        self.indent_str = " " * indent
        self.rows = []
        
        # 制表符定义
        self.box = {
            "tl": "┌", "tm": "┬", "tr": "┐",
            "ml": "├", "mm": "┼", "mr": "┤",
            "bl": "└", "bm": "┴", "br": "┘",
            "v":  "│", "h":  "─"
        }

    def _pad_cell(self, text, target_width):
        """
        核心逻辑：根据显示宽度手动补空格
        """
        text = str(text)
        vis_width = get_display_width(text)
        
        # 计算需要补多少个空格
        padding = target_width - vis_width
        
        # 如果内容过长，暂时不截断以免破坏中文结构，直接返回(会撑破表格，提示开发者调宽列宽)
        # 如果需要截断逻辑会比较复杂，这里优先保证对齐
        if padding < 0:
            padding = 0 
            
        return text + " " * padding

    def _get_line(self, left, mid, right):
        """生成横向分割线"""
        # 每一段的横线长度 = 列宽 + 2 (左右padding)
        segments = [self.box["h"] * (w + 2) for w in self.col_widths]
        return self.indent_str + left + mid.join(segments) + right

    def add_row(self, *args):
        """添加数据行"""
        # 补齐列数
        data = list(args) + [""] * (len(self.col_widths) - len(args))
        self.rows.append({"type": "data", "content": data})

    def add_separator(self):
        """添加横向分隔线"""
        self.rows.append({"type": "sep"})

    def print(self, printer_func=print_log):
        """执行打印"""
        if not self.rows:
            return

        # 1. 顶部
        printer_func(self._get_line(self.box["tl"], self.box["tm"], self.box["tr"]))

        # 2. 内容
        for row in self.rows:
            if row["type"] == "data":
                # 核心改动：不再使用 format 自动对齐，而是手动计算 padding
                # 每一列结构: " 文本...空格 " (左右各有一个固定空格作为 Padding)
                cells = []
                for i, text in enumerate(row["content"]):
                    padded_text = self._pad_cell(text, self.col_widths[i])
                    cells.append(f" {padded_text} ")
                
                line = self.indent_str + self.box["v"] + self.box["v"].join(cells) + self.box["v"]
                printer_func(line)
            
            elif row["type"] == "sep":
                printer_func(self._get_line(self.box["ml"], self.box["mm"], self.box["mr"]))

        # 3. 底部
        printer_func(self._get_line(self.box["bl"], self.box["bm"], self.box["br"]))