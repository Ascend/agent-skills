import os
import datetime
import numpy as np
import pandas as pd

# === 辅助打印函数 ===

class Colors:
    """存放终端颜色代码"""
    # 格式：\033[显示方式;前景色;背景色m
    
    # 常用前景色
    RED = '\033[31m'       # 红
    GREEN = '\033[32m'     # 绿
    YELLOW = '\033[33m'    # 黄
    BLUE = '\033[34m'      # 蓝
    MAGENTA = '\033[35m'   # 紫
    CYAN = '\033[36m'      # 青
    WHITE = '\033[37m'     # 白
    GRAY = '\033[90m'      # 灰

    # 样式
    RESET = '\033[0m'      # 重置
    BOLD = '\033[1m'       # 加粗
    UNDERLINE = '\033[4m'  # 下划线

class ConstConfig:
    """存放业务常量"""
    # 打印分割线的总长度，修改这里会影响所有分割线
    MAX_LEN = 90
    MAX_LEN_SINGLE_HELP = 78
    MAX_LEN_SINGLE_REPORT = 70
    MAX_LEN_DUAL_HELP = 82
    MAX_LEN_DUAL_REPORT = 80

def print_log(data=None):
    print("[CT]", data)

def print_log_error(data=None, is_digit=True):
    if is_digit:
        print("[CT]", data)
    else:
        # 使用 Colors.RED 和 Colors.RESET
        print("[CT]", f"{Colors.RED}{data}{Colors.RESET}")
        
def print_log_info(data=None):
    print("\033[96m[i]\033[0m", data)

# === 文件IO函数 ===

def print_config_semantics(args, subparser_map):
    """
    自动解析当前命令的参数，打印：[参数名] = [当前值]  (语义说明)
    """
    if not args.command or args.command not in subparser_map:
        return

    active_parser = subparser_map[args.command]
    
    if hasattr(args, 'test') and args.test in ['tips', 'help', 'analyze']:
        return
    # 组合颜色：加粗 + 青色
    header_color = f"{Colors.BOLD}{Colors.CYAN}"
    help_color = f"{Colors.BOLD}{Colors.YELLOW}"
    print_log(f"可以使用 {help_color}ct {args.command} help {Colors.RESET}命令获取帮助信息")
    # 动态计算标题分割线长度
    title_str = f" [您的输入内容为: {args.command}] "
    pad_len = max((ConstConfig.MAX_LEN - len(title_str) - 6) // 2, 0)
    separator = '=' * pad_len
    
    
    
    print_log(f"{header_color}{separator}{title_str}{separator}{Colors.RESET}")
    
    for action in active_parser._actions:
        if action.dest == 'help':
            continue
            
        value = getattr(args, action.dest, None)
        
        if value is not None:
            arg_name = action.option_strings[0] if action.option_strings else action.dest
            
            # 使用 Colors.WHITE (灰色/白色) 替代原来的 \033[90m
            print_log(f"  {arg_name:<15} : {str(value):<15}  {Colors.GRAY}({action.help}){Colors.RESET}")
            
    # 底部横线使用 MAX_LEN
    print_log(f"{header_color}{'=' * ConstConfig.MAX_LEN}{Colors.RESET}")

def save_compare_report(result_status, details_msg, output_dir="ct/result", filename="close_result.csv"):
    """
    独立出来的 CSV 保存逻辑
    """
    current_cwd = os.getcwd()
    full_dir_path = os.path.join(current_cwd, output_dir)
    full_file_path = os.path.join(full_dir_path, filename)

    if not os.path.exists(full_dir_path):
        try:
            os.makedirs(full_dir_path)
        except OSError as e:
            print(f"[!] Error creating directory {full_dir_path}: {e}")
            return

    csv_data = {
        "Timestamp": [datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
        "Result": [result_status],
        "Details": [details_msg]
    }
    new_df = pd.DataFrame(csv_data)

    try:
        if os.path.exists(full_file_path):
            new_df.to_csv(full_file_path, mode='a', header=False, index=False, encoding='utf-8_sig')
        else:
            new_df.to_csv(full_file_path, index=False, encoding='utf-8_sig')
        print_log(f"检查结果保存在: {full_file_path}")
    except Exception as e:
        print(f"[!] Failed to save CSV: {e}")

# === 数学计算函数 ===

def cal_relative_diff_np(real_data, expect_data, diff_thd):
    """
    向量化计算相对误差
    """
    a = np.abs(np.subtract(real_data, expect_data))
    b1 = np.maximum(np.abs(real_data), (np.abs(expect_data)))
    b2 = float((1.0 / (1 << 14)) / diff_thd)
    b = np.add(np.maximum(b1, b2), 10e-10)
    result = np.where(a < diff_thd, a, a / b)
    return result

def cal_relative_diff(real_data, expect_data, diff_thd, type_str='fp16'):
    """
    标量计算相对误差（用于打印显示）
    """
    if 'nan' in str(expect_data) or 'inf' in str(expect_data):
        if type_str.lower() == 'fp16':
            expect_data = 65504
        else:
            expect_data = 3.4028e38
    diff = abs(float(real_data) - float(expect_data))

    result = diff / (float(max(abs(real_data), abs(expect_data))) + 10e-10)
    return result

# === 显示输出函数 ===

def display_output(real_data, expect_data, start, end, diff_thd):
    def display_inner(idx):
        j = idx + start
        diff_rate = cal_relative_diff(expect_data[j], real_data[j], diff_thd)
        if "inf" in str(expect_data[j]) or "nan" in str(expect_data[j]):
            diff_abs = "inf" if "inf" in str(expect_data[j]) else "nan"
            # 为了对齐科学计数法的宽度，将 %-7s 调整为 %-12s
            print_log('%08d \t %-12s \t %-12s \t %-12s \t %-12s' % (start + idx, expect_data[j], real_data[j], diff_abs, diff_rate))
        else:
            diff_abs = abs(np.float64(expect_data[j]) - np.float64(real_data[j]))
            # 修改点：将 %0.7f 替换为 %.6e (Scientific Notation)
            # 示例输出：1.234567e-05
            print_log('%08d \t %.6e \t %.6e \t %.6e \t %.6e' % (start + idx, expect_data[j], real_data[j], diff_abs, diff_rate))

    # 使用 ConstConfig.MAX_LEN 替换硬编码的横线
    separator = '-' * ConstConfig.MAX_LEN
    print_log(separator)
    print_log('位置 \t 期望值 \t 待测值 \t 绝对误差 \t 相对误差')
    print_log(separator)
    
    split_count = int(end - start)
    if split_count <= 10:
        for i in range(split_count + 1):
            display_inner(i)
    else:
        for i in range(3):
            display_inner(i)
        print_log('  ...  \t     ...   \t     ...   \t     ...    \t     ...')
        for i in range(split_count - 3 + 1, split_count + 1):
            display_inner(i)

def display_error_output(real_data, expect_data, err_idx, relative_diff):
    # 动态计算 error 标题栏
    title = "error"
    pad_len = max((ConstConfig.MAX_LEN - len(title)) // 2, 0)
    err_header = '-' * pad_len + title + '-' * pad_len
    
    print(f"{Colors.RED}{err_header}{Colors.RESET}")
    
    print_log_error('位置 \t 期望值 \t 待测值 \t 绝对误差 \t 相对误差')
    print_log_error('-' * ConstConfig.MAX_LEN, is_digit=False)
    
    count = 0
    len_err = len(err_idx)
    for i in err_idx:
        count += 1
        if count < 21 or (96 < count < 100):
            # 修改点：将 %.7f 改为 %.7e
            print_log_error('%08d \t %.7e \t %.7e \t %.7e \t %.7e' % 
                (i, expect_data[i], real_data[i], abs(np.float64(expect_data[i]) - np.float64(real_data[i])), relative_diff[count - 1]))
        elif count == 21 or (count == 100 and len_err > 100):
            dot_3 = '...'
            # 修改点：增加占位宽度以对齐科学计数法 (6 -> 12)
            print_log_error('%05s\t %012s \t %012s \t %012s \t %012s' %(dot_3, dot_3, dot_3, dot_3, dot_3))
        elif count > 100:
            break

    # 动态计算 Max-RE-line 标题栏
    max_title = "Max-RE-line"
    pad_len_max = max((ConstConfig.MAX_LEN - len(max_title)) // 2, 0)
    max_header = '-' * pad_len_max + max_title + '-' * pad_len_max
    
    print_log_error(max_header, is_digit=False)
    
    max_error = max(relative_diff)
    m_idx_list = err_idx[np.where(relative_diff == max_error)]
    m_count = 0
    for m_idx in m_idx_list:
        m_count += 1
        if m_count < 4:
            print_log_error('%08d \t %.7f \t %.7f \t %.7f \t %.7f' % (
                m_idx, expect_data[m_idx], real_data[m_idx],
                abs(np.float64(expect_data[m_idx]) - np.float64(real_data[m_idx])), max_error))
        else:
            break
            
    print(f"{Colors.RED}{'-' * ConstConfig.MAX_LEN}{Colors.RESET}")
    
    # 使用 Colors.YELLOW 替换 \033[93m
    warning_prefix = f"{Colors.YELLOW}[> warning <]{Colors.RESET}"
    print(warning_prefix, "第一个报错位置在%d" % err_idx[0])
    print(warning_prefix, "最后一个报错位置在%d" % err_idx[-1])