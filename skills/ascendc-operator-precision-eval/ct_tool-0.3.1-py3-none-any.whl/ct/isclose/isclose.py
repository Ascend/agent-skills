import numpy as np
# 导入公共模块
from ct.utils import common

# 尝试导入 bfloat16ext (保留特定的硬件/数据类型支持逻辑)
try:
    import bfloat16ext
except ImportError:
    bfloat16ext = None

# === 核心入口函数 ===

def _isclose_impl(npu_output, cpu_output, diff_thd=0.001, pct_thd=0.001, max_diff_hd=0.1):
    """
    Main entry for comparison logic.
    """
    if isinstance(npu_output, list):
        print("\033[93m[> 警告 <]\033[0m", "isclose第一个值传的是list,工具将为你默认比较第0个值.")
        npu_output = npu_output[0]
    if isinstance(cpu_output, list):
        print("\033[93m[> 警告 <]\033[0m", "isclose第二个值传的是list,工具将为你默认比较第0个值.")
        cpu_output = cpu_output[0]
    if not isinstance(npu_output, np.ndarray):
        npu_output = np.array(npu_output)
    if not isinstance(cpu_output, np.ndarray):
        cpu_output = np.array(cpu_output)
    
    # bfloat16 处理
    try:
        if npu_output.dtype == "|V2" and bfloat16ext:
            npu_output.dtype = "bfloat16"
    except Exception:
        pass
    
    # --- 2. 核心比较逻辑封装 (内部函数) ---
    def _verify_single_precision(name, real_data_in, data_compe_in):

        # 调用 common.print_log
        common.print_log(f"=" * 70)
        
        max_error_idx = 10000000
        real_data = real_data_in.flatten()
        data_compe = data_compe_in.flatten()
        
        # 空数据检查
        if real_data.size == 0 and real_data.size == data_compe.size:
            common.print_log('The data is [], result is "Pass"')
            return "Pass", 100.0, 0, "success"

        start = 0
        end = real_data.size - 1
        max_error = 0
        result = "Failed"

        # 尺寸检查
        if real_data.size != data_compe.size:
            print("\033[31m[> error <]\033[0m", f"精度比对失败. {name} size mismatch: {real_data.size} vs {data_compe.size}")
            return result, 0.0, max_error, f"{name} size mismatch"

        # 溢出检查
        overflows_count = data_compe[np.isinf(data_compe)].size + data_compe[np.isnan(data_compe)].size
        if overflows_count > 0:
            common.print_log(f'Overflow in {name}, size:{overflows_count}')

        split_count = int(end - start + 1) if end != start else 1

        # === 计算误差 ===
        try:
            diff_abs = np.abs(np.subtract(real_data.astype(np.float32), data_compe.astype(np.float32)))
        except MemoryError:
            print("\033[31m[> error <]\033[0m", "MemoryError during subtraction")
            return result, 0.0, max_error, "MemoryError"

        diff_index = np.where(diff_abs > 0)
        
        # 调用 common.cal_relative_diff_np
        rdiff = common.cal_relative_diff_np(
            real_data[diff_index].astype(np.float32), 
            data_compe[diff_index].astype(np.float32), 
            diff_thd
        )

        err_diff = rdiff[rdiff > diff_thd]
        diff_idx_list = diff_index[0]
        err_idx = diff_idx_list[np.where(rdiff > diff_thd)]

        fulfill_percent = float(split_count - err_diff.size) / float(split_count) * 100.0

        # === 结果判定与展示 ===
        # 调用 common.display_output
        common.display_output(real_data, data_compe, start, end, diff_thd)
        
        pct_thd_val = (1 - pct_thd) * 100.0
        result = "success" if (fulfill_percent >= pct_thd_val) else "failed"

        if len(err_diff) > 0:
            max_error = max(err_diff[0:max_error_idx])
            if max_error >= max_diff_hd:
                result = "failed"

        # === 打印日志 ===
        common.print_log('------------------------------------------------------------------------')
        common.print_log(f'DiffThd \t PctThd \t PctRlt \t Result')
        common.print_log('%.4f \t %.2f%% \t %.6f%% \t %s' % (diff_thd, pct_thd_val, fulfill_percent, result))
        
        if len(err_diff) > 0:
            common.print_log('------------------------------------------------------------------------')
            common.print_log(f'[{name}] 最大相对误差: {max_error}. 最大允许误差: {max_diff_hd}.')
            common.print_log('------------------------------------------------------------------------')

        csv_msg = "success"
        if result == "failed":
            # 调用 common.display_error_output
            common.display_error_output(real_data, data_compe, err_idx, err_diff[0:max_error_idx])
            csv_msg = f"[{name}] result:{result}; fulfill_percent:{fulfill_percent:.4f}; max_error={max_error:.6f}"
            if len(err_idx) > 0:
                 csv_msg += f"; first_err_idx:{err_idx[0]}"
        common.print_log("=" * 70)
        return result, fulfill_percent, max_error, csv_msg

    # 检查是否为复数
    if np.iscomplexobj(npu_output) or np.iscomplexobj(cpu_output):
        common.print_log("\033[96m[i] 检测到复数数据，将分离实部和虚部进行校验...\033[0m")
        
        # 校验实部
        res_real, pct_real, err_real, msg_real = _verify_single_precision(
            "RealPart", np.real(npu_output), np.real(cpu_output)
        )
        
        # 校验虚部
        res_imag, pct_imag, err_imag, msg_imag = _verify_single_precision(
            "ImagPart", np.imag(npu_output), np.imag(cpu_output)
        )
        
        final_result = "success" if (res_real == "success" and res_imag == "success") else "failed"
        final_percent = min(pct_real, pct_imag)
        final_max_error = max(err_real, err_imag)
        final_msg = f"{msg_real} | {msg_imag}"
        
        if final_result == "failed":
            common.print_log(f"\033[31m[!] 复数校验失败: 实部[{res_real}] / 虚部[{res_imag}]\033[0m")
            
        return final_result, final_percent, final_max_error, final_msg

    else:
        # --- 非复数，走标准流程 ---
        return _verify_single_precision("Standard", npu_output, cpu_output)